﻿namespace PI.WebGarten
{
    public class HttpMethod
    {
        public const string Get = "GET";
        public const string Post = "POST";
    }
}