﻿using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class WebForms_AccumulatorPage1CodeBehind : System.Web.UI.Page 
{

    protected override void OnInit(EventArgs e)
    //protected void MyInit(Object sender, EventArgs e)
    {
      base.OnInit(e);
      String lblText = lbl.Text;
    }


    protected override void OnLoad(EventArgs e)
    {
        base.OnLoad(e);
        String lblText = lbl.Text;
    }

    protected void btn_Click(object sender, EventArgs args)
    {
        lbl.Text = (int.Parse(lbl.Text) + 1).ToString();
    }
}
