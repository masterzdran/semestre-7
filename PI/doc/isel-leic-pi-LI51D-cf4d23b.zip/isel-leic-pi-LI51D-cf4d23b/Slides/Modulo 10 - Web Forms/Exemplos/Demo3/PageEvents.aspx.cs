using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class PageEvents : System.Web.UI.Page 
{

  protected override void OnInit(EventArgs e) 
  {
    base.OnInit(e);
    this.Load += new EventHandler(PageEvents_Load);
  }

  void PageEvents_Load(object sender, EventArgs e) 
  {
    TextoResultante += " [ Load Event ] ";
  }

  protected void Page_Load(object sender, EventArgs e) 
  {
    TextoResultante += " [ Page_Load @ CodeBehind ] ";
  }

  protected override void OnLoad(EventArgs e) 
  {
    TextoResultante += " [ Before OnLoad ] ";
    base.OnLoad(e);
    TextoResultante += " [ After OnLoad ] ";
  }

  protected string TextoResultante = String.Empty;

}




 
