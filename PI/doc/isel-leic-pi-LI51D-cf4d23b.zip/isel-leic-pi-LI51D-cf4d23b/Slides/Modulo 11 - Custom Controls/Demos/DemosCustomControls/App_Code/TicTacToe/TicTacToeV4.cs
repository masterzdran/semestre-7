﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;



namespace PI.Controls {

  /// <summary>
  /// Versão em que se resolve o problema da 
  /// multipla inclusão do elemento <link />
  /// </summary>
  public class TicTacToeV4 : Control {

    public bool LinkAlreadyPresent { 
      set {
        this.Context.Items["LinkAlreadyPresent"] = value;
      }
      get {
        //bool? res = this.Context.Items["LinkAlreadyPresent"];
        //return res == null ? false : res.Value;
        object o = this.Context.Items["LinkAlreadyPresent"];
        return o == null ? false : (bool)o;
      }
    }

    protected override void OnPreRender(EventArgs e) {
      base.OnPreRender(e);

      Page.Trace.Warn("Link ?");
      if(!LinkAlreadyPresent) {

        Page.Trace.Warn("Link Not Present");

        LiteralControl link = new LiteralControl();
        link.ID = "myLink";
        string linkURL = this.Context.Response.ApplyAppPathModifier("~/css/TicTacToeV3.css");
        link.Text = string.Format("<link rel='Stylesheet' href='{0}' />", linkURL);
        this.Page.Header.Controls.AddAt(0, link);

        // Registar o script
        string scriptURL = this.Context.Response.ApplyAppPathModifier("~/script/TicTacToeV3.js");
        string eventsURL = this.Context.Response.ApplyAppPathModifier("~/script/events.js");
        Page.ClientScript.RegisterClientScriptInclude("tictactoescript", scriptURL);
        Page.ClientScript.RegisterClientScriptInclude("eventScript", eventsURL);

        LinkAlreadyPresent = true;
      }

    }

    protected override void Render(HtmlTextWriter writer) {
      Page.Trace.Warn("Render ");

      base.Render(writer);

      // Funciona!! Mas está mal feito :-(
      //writer.Write("<link rel='Stylesheet' href='../css/TicTacToeV2.css' />");

      writer.AddAttribute(HtmlTextWriterAttribute.Class, "tictactoe");
      writer.RenderBeginTag(HtmlTextWriterTag.Div);

      for(int i = 0; i < 3; i++) {
        writer.AddAttribute(HtmlTextWriterAttribute.Class, "line");
        writer.RenderBeginTag(HtmlTextWriterTag.Div);
        for(int j = 0; j < 3; j++) {
          writer.AddAttribute(HtmlTextWriterAttribute.Class, "cell");
          writer.AddAttribute(HtmlTextWriterAttribute.Onclick, "cellClick();");
          writer.RenderBeginTag(HtmlTextWriterTag.Span);
          writer.Write("&nbsp;");
          writer.RenderEndTag();
        }
        writer.RenderEndTag();
      }

      writer.RenderEndTag();





    }


  }

}