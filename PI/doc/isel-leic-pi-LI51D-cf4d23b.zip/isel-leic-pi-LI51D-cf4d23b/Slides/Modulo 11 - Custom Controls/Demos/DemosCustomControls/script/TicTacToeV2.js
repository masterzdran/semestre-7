﻿
var chars = ['O', 'X'];
var currentTurn = 0;


function cellClick() {

  // Obter o elemento actual (do click) a partir
  //  da informação do evento
  var event = getEvent();
  var elem = event.target;

  // "escrever" o char actual no elem
  //elem.appendChild( document.createTextNode( chars[currentTurn] ) );
  if(!elem.hasValue) {
    elem.firstChild.nodeValue = chars[currentTurn];
    elem.hasValue = true;
    currentTurn = (++currentTurn) % 2;
  }

}