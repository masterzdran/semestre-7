// Vers�o ing�nua e ERRADA !!!
var g_tictactoe_stateW = true;//new Object();

var PLAYER1_CHAR = "O";
var PLAYER2_CHAR = "Y";

function OnClickCellW(cell, idx) {
	if (cell.innerHTML != PLAYER1_CHAR && cell.innerHTML != PLAYER2_CHAR) {
		if (g_tictactoe_stateW) {
			cell.innerHTML = PLAYER1_CHAR;
							
		} else {
			cell.innerHTML = PLAYER2_CHAR;
			
		}
		g_tictactoe_stateW = !g_tictactoe_stateW;
	}
}

var g_tictactoe_state = new Object();

function OnClickCell1(cell, id) {
	if (cell.innerHTML != PLAYER1_CHAR && cell.innerHTML != PLAYER2_CHAR) {
		if (g_tictactoe_state[id]) {
			cell.innerHTML = PLAYER1_CHAR;
							
		} else {
			cell.innerHTML = PLAYER2_CHAR;
			
		}
		g_tictactoe_state[id] = !g_tictactoe_state[id];
	}
}

function OnClickCell(cell, id, idx) {
	if (cell.innerHTML != PLAYER1_CHAR && cell.innerHTML != PLAYER2_CHAR) {
	    var game;
	    if ( (game = g_tictactoe_state[id]) ==  undefined) {
	        game = g_tictactoe_state[id] = new Game();
	    }
	    var p;
		if (game.nextPlayer) {
			p = cell.innerHTML = PLAYER1_CHAR;
							
		} else {
			p = cell.innerHTML = PLAYER2_CHAR;
			
		}
		game.nextPlayer = !game.nextPlayer;
		
		game.cells[idx] = p;
		// Update hidden field
	    //updateHiddenField(id);    
	    //alert(hidden.value);
	}
}


function addGame(id, game) {
    var g1 = g_tictactoe_state[id] = new Game();
    g1.nextPlayer = game.nextPlayer;
    g1.cells = game.cells;
}

function updateHiddenField(id) {
    var div = document.getElementById(id);
	var hidden = div.getElementsByTagName("input")[0];
	hidden.value = g_tictactoe_state[id].toString();
}


function Game() {
    this.nextPlayer = true;
    this.cells = [' ', ' ',' ',' ',' ',' ',' ',' ',' '];
}

Game.prototype.toString = function() {
    return "{ nextPlayer: " + this.nextPlayer + ", cells: " + this.cells.specialToString() + "}";
}

Array.prototype.specialToString = function() {
    var str = "[";
    for(var i = 0; i < this.length; ++i) {
        str += (i == 0 ? "" : ",") + "'" + this[i].toString() + "'";
    }
    return str + "]";
} 
