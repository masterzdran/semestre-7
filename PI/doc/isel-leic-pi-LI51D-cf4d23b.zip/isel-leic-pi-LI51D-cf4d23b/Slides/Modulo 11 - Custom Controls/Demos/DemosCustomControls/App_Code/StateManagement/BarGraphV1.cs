﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;



namespace PI.Controls {

  /// <summary>
  /// Gráfico de barras horizontal
  /// </summary>
  public class BarGraphV1 : Control {

    private Unit width = Unit.Empty;
    public Unit Width {
      set { width = value; }
      get { return width;  }
    }

    //private int[] values = null;
    //public int[] Values {
    //  set { values = value; }
    //  get { return values;  }
    //}

    public int[] Values {
      set { ViewState["Values"] = value; }
      get { return (int[])ViewState["Values"]; }
    }


    protected override void Render(HtmlTextWriter writer) {
      base.Render(writer);

      // writer.AddAttribute(
      //writer.AddStyleAttribute(HtmlTextWriterStyle.Width, Width.ToString());

      Style s = new Style();
      s.Width = Width;
      s.BorderColor = System.Drawing.Color.Black;
      s.BorderStyle = BorderStyle.Solid;
      s.BorderWidth = Unit.Pixel(1);
      s.AddAttributesToRender(writer);
      writer.RenderBeginTag(HtmlTextWriterTag.Div);


      if(Values == null)
      {
        writer.Write("Empty graph");
      }
      else 
      {

        int maxValue = Values[0];
        for(int i = 1; i < Values.Length; i++) {
          if(Values[i] > maxValue)
            maxValue = Values[i];
        }

        Style itemStyle = new Style();
        itemStyle.BackColor = System.Drawing.Color.DarkGray;

        for(int i = 0; i < Values.Length; i++) {
          //writer.Write(Values[i]);
          //writer.WriteBreak();

          itemStyle.Width = Unit.Percentage( ((double)Values[i] / maxValue) * 100);
          itemStyle.AddAttributesToRender(writer);
          writer.AddStyleAttribute(HtmlTextWriterStyle.MarginTop, "4px");
          writer.AddStyleAttribute(HtmlTextWriterStyle.MarginBottom, "4px");
          writer.AddStyleAttribute(HtmlTextWriterStyle.TextAlign, "center");
          writer.RenderBeginTag(HtmlTextWriterTag.Div);
          writer.Write(Values[i]);
          writer.RenderEndTag();

        }
      }

      writer.RenderEndTag(); // div

    }

  }

}