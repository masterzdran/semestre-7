﻿

function validateFieldsAndCalc(elemAID, elemBID, elemResID)  {

  var a = document.getElementById(elemAID);
  var b = document.getElementById(elemBID);
  var r = document.getElementById(elemResID);
  
  var aint = parseInt( a.value, 10 );
  var bint = parseInt( b.value, 10 );
  
  if(isNaN(aint) || isNaN(bint)) {
    alert("ERRO");
    return false;
  }
  else {
    //alert("Ok: Valores = (" + aint + " + " + bint + ")");
    
    var xhr = new XMLHttpRequest();
    var url = "CalcHandlerXML.ashx";
    
    xhr.onreadystatechange = function() {
      if(xhr.readyState == 4 ) { /* DONE */ 
        alert("Text: " + xhr.responseText);
        alert("XML:  " + xhr.responseXML);
        r.value = xhr.responseXML.firstChild.firstChild.nodeValue;
      }
    };
    
    xhr.open("GET", url, true /* async */);
    xhr.send(null);
    
    return /*true*/ false; // false porque NUNCA queremos postback (pedido feito via AJAX)
  }

}
