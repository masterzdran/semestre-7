﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;



namespace PI.Controls {

  public class TicTacToeV3 : Control {


    protected override void OnPreRender(EventArgs e) {
      base.OnPreRender(e);

      LiteralControl link = new LiteralControl();
      link.ID = "myLink";
      string linkURL = this.Context.Response.ApplyAppPathModifier("~/css/TicTacToeV3.css");
      link.Text = string.Format("<link rel='Stylesheet' href='{0}' />", linkURL);
      this.Page.Header.Controls.AddAt(0, link);

      // Registar o script
      string scriptURL = this.Context.Response.ApplyAppPathModifier("~/script/TicTacToeV3.js");
      string eventsURL = this.Context.Response.ApplyAppPathModifier("~/script/events.js");
      Page.ClientScript.RegisterClientScriptInclude("tictactoescript", scriptURL);
      Page.ClientScript.RegisterClientScriptInclude("eventScript", eventsURL);

    }

    protected override void Render(HtmlTextWriter writer) {
      base.Render(writer);

      // Funciona!! Mas está mal feito :-(
      //writer.Write("<link rel='Stylesheet' href='../css/TicTacToeV2.css' />");

      writer.AddAttribute(HtmlTextWriterAttribute.Class, "tictactoe");
      writer.RenderBeginTag(HtmlTextWriterTag.Div);

      for(int i = 0; i < 3; i++) {
        writer.AddAttribute(HtmlTextWriterAttribute.Class, "line");
        writer.RenderBeginTag(HtmlTextWriterTag.Div);
        for(int j = 0; j < 3; j++) {
          writer.AddAttribute(HtmlTextWriterAttribute.Class, "cell");
          writer.AddAttribute(HtmlTextWriterAttribute.Onclick, "cellClick();");
          writer.RenderBeginTag(HtmlTextWriterTag.Span);
          writer.Write("&nbsp;");
          writer.RenderEndTag();
        }
        writer.RenderEndTag();
      }

      writer.RenderEndTag();





    }


  }

}