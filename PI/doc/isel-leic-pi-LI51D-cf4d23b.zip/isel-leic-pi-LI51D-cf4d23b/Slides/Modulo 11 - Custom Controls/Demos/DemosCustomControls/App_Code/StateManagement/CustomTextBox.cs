using System;
using System.Web;
using System.Web.UI;
using System.Collections.Specialized;
using System.Web.UI.WebControls;

namespace PI.Controls
{
	public class CustomTextBox: WebControl, IPostBackDataHandler
	{
		string _oldValue;
		string _postedValue;

		public string Text
		{
			get
			{
				return (string) ViewState["Text"];
			}
			set
			{
				ViewState["Text"] = value;
			}
		}

		public string TextOld
		{
			get { return _oldValue; }
		}

		public event EventHandler TextChanged;

		protected override void LoadViewState(object savedState)
		{
			base.LoadViewState (savedState);
		}

		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad (e);
		}



		public virtual bool LoadPostData(string postDataKey,
			NameValueCollection postCollection)
		{
			this.Page.Trace.Warn("CustomTextBox", "LoadPostData");
			_oldValue = Text;
			_postedValue = postCollection[postDataKey];

			if (_oldValue == null ||
				!_oldValue.Equals(_postedValue))
			{
				Text = _postedValue;
				return true;
			}
			return false;
		}

		public virtual void RaisePostDataChangedEvent()
		{
			this.Page.Trace.Warn("CustomTextBox", "RaisePostDataChangedEvent");
			if (TextChanged != null)
				TextChanged(this,EventArgs.Empty);
		}

		protected override void Render(HtmlTextWriter output)
		{
			this.Page.Trace.Warn("CustomTextBox", "Render");
			output.AddAttribute(HtmlTextWriterAttribute.Name,
				UniqueID);
			output.AddAttribute(HtmlTextWriterAttribute.Value,
				Text);
			output.RenderBeginTag(HtmlTextWriterTag.Input);
			output.RenderEndTag();
		}
	}
}
