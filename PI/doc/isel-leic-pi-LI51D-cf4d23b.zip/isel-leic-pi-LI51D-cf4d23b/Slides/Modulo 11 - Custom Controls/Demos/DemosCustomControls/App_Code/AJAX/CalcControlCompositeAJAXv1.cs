﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;



namespace PI.Controls {

  /// <summary>
  /// Calculadora... em AJAX :-)
  /// </summary>
  public class CalcControlCompositeAJAXv1 : Control, INamingContainer {

    protected override void OnInit(EventArgs e) {
      base.OnInit(e);
      //EnsureChildControls();
    }

    protected override void OnLoad(EventArgs e) {
      base.OnLoad(e);
      EnsureChildControls();
    }

    TextBox txtOpA = null;
    TextBox txtOpB = null;
    TextBox txtRes = null;

    protected override void CreateChildControls() {
      base.CreateChildControls();

      Page.Trace.Warn("CreateChildControls");

      // Contrução de Controlos
      LiteralControl lcPlus   = new LiteralControl("+");
      txtOpA = new TextBox();
      txtOpB = new TextBox();
      txtRes = new TextBox();
      LiteralControl lcEquals = new LiteralControl("=");
      Button btnCalc          = new Button();

      // Adição filhos
      Controls.Add(txtOpA);
      Controls.Add(lcPlus);
      Controls.Add(txtOpB);
      Controls.Add(lcEquals);
      Controls.Add(txtRes);
      Controls.Add(btnCalc);


      // Definição de valores
      txtOpA.ID = "txtOpA";
      txtOpB.ID = "txtOpB";
      txtRes.ID = "txtRes";
      btnCalc.Text = "Calc.";
      btnCalc.Click += new EventHandler(btnCalc_Click);
            
      string scriptFuncCall = 
        string.Format("return validateFieldsAndCalc('{0}', '{1}', '{2}')", 
                      txtOpA.ClientID/*ID*/, txtOpB.ClientID, txtRes.ClientID);

      btnCalc.OnClientClick = scriptFuncCall;

      Page.ClientScript.RegisterClientScriptInclude(
        "CALC_CONTROL", 
        //Page.Response.ApplyAppPathModifier("~/script/CalcCompositeControlAJAXv1.js")
        Page.Response.ApplyAppPathModifier("~/script/CalcCompositeControlAJAXv2XML.js")
      );


    }

    void btnCalc_Click(object sender, EventArgs e) {

      Page.Trace.Warn("btnCalc_Click");

      string res = String.Empty;
      try {
        int a = int.Parse(txtOpA.Text);
        int b = int.Parse(txtOpB.Text);
        res = (a + b).ToString();
      }
      catch {
        res = "Error";
      };
      txtRes.Text = res;

    }


  }

}