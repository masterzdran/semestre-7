﻿

function validateFields(elemAID, elemBID)  {


  var a = document.getElementById(elemAID);
  var b = document.getElementById(elemBID);
  
  var aint = parseInt( a.value, 10 );
  var bint = parseInt( b.value, 10 );
  
  if(isNaN(aint) || isNaN(bint)) {
    alert("ERRO");
    return false;
  }
  else {
    alert("Ok: Valores = (" + aint + " + " + bint + ")");
    return true;
  }

}