﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;



namespace PI.Controls {

  /// <summary>
  /// Summary description for Class1
  /// </summary>
  public class NameControl : Control {

    private string text;
    public string Text {
      get { return text; }
      set { text = value; }
    }

    private bool isImportant;
    public bool IsImportant {
      get { return isImportant; }
      set { isImportant = value; }
    }

    
    protected override void  Render(HtmlTextWriter writer)
    {
 	     base.Render(writer);
      

      //if(this.Site != null) {
      //  writer.Write("Demo: " + Text);
      //} else {

        if(IsImportant) writer.Write("<b>");
        writer.Write(Text);
        if(IsImportant) writer.Write("</b>");
      //}

    }


  }

}