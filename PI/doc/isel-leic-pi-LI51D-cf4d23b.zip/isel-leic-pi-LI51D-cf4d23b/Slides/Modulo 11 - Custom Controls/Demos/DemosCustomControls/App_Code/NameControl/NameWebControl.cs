﻿using System;
using System.Data;
using System.Drawing;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;



namespace PI.Controls {

  /// <summary>
  /// Custom controlo que é um WebControl
  /// Sendo um WebControl, o controlo deve "dar uso" ao valor
  ///  das propriedades definidas pela classe base (WebControl),
  ///  nomeadamente as seguintes:
  ///    AccessKey 	 (string)
  ///    BackColor 	 (Color)      
  ///    BorderColor (Color)       
  ///    BorderStyle (BorderStyle)
  ///    BorderWidth (Unit) 
  ///    CssClass 	 (string)      
  ///    Enabled 	   (bool)
  ///    Font        (FontInfo)
  ///    ForeColor 	 (Color)
  ///    Height 	   (Unit)
  ///    TabIndex 	 (short)
  ///    ToolTip 	   (string)      
  ///    Width 	     (Unit)
  /// </summary>
  public class NameWebControl : WebControl {

    public NameWebControl() 
    {

    }


    private string text;
    public string Text {
      get { return text; }
      set { text = value; }
    }

    private bool isImportant;
    public bool IsImportant {
      get { return isImportant; }
      set { isImportant = value; }
    }

    protected override void Render(HtmlTextWriter writer) {
      // Em comentário para não ser executado o código da classe base!! (por causa da tag por omissão)
      //base.Render(writer);

      ///    AccessKey 	 (string)
      ///    BackColor 	 (Color)      
      ///    BorderColor (Color)       
      ///    BorderStyle (BorderStyle)
      ///    BorderWidth (Unit) 
      ///    CssClass 	 (string)      
      ///    Enabled 	   (bool)
      ///    Font        (FontInfo)
      ///    ForeColor 	 (Color)
      ///    Height 	   (Unit)
      ///    TabIndex 	 (short)
      ///    ToolTip 	   (string)      
      ///    Width 	     (Unit)

      // Vamos colocar o conteúdo dentro de um DIV para definir 
      //  as suas propriedades de estilo
      this.ControlStyle.AddAttributesToRender(writer);
      writer.RenderBeginTag(HtmlTextWriterTag.Div);

      if(IsImportant) writer.RenderBeginTag(HtmlTextWriterTag.B);
      writer.Write(Text);
      if(IsImportant) writer.RenderEndTag();  // B

      writer.RenderEndTag();  // DIV
    }


  }

}