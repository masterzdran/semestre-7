﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

public partial class Demos_RichCalendar : System.Web.UI.Page
{

  protected override void OnInit(EventArgs e) {
    base.OnInit(e);
    cal.SelectionChanged += new EventHandler(cal_SelectionChanged);

    ddlMonths.Items.Add(new ListItem("Abril", "4"));
    ddlMonths.Items.Add(new ListItem("Maio",  "5"));
    ddlMonths.Items.Add(new ListItem("Junho", "6"));

    //System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("en-US");

  }

  void cal_SelectionChanged(object sender, EventArgs e) {

    txt.Text = cal.SelectedDate.ToLongDateString();

  }

  protected void selectDateCB(object sender, EventArgs e) {

    int d = cal.SelectedDate.Day;
    int m = int.Parse(ddlMonths.SelectedItem.Value);
    int a = cal.SelectedDate.Year;
    DateTime dt = new DateTime(a, m, d);
    cal.SelectedDate = dt;
    cal.VisibleDate = dt;

  }

}
