﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

/// <summary>
/// Summary description for PageEvents
/// </summary>
public partial class PageEvents : Page
{
  protected override void OnPreInit(EventArgs e) {
    base.OnPreInit(e);
    this.Init += new EventHandler(PageEvents_Init);
  }


  void PageEvents_Init(object sender, EventArgs e) {
    lbl.Text += "OnInit (event) -> ";
  }


  protected override void OnInit(EventArgs e) {
    base.OnInit(e);
    lbl.Text += "OnInit (overrided) -> ";
  }

  protected void Page_Init(object sender, EventArgs e) {
    lbl.Text += "OnInit (AutoEventWireUp - CodeFile) -> ";
  }


}
