﻿
var xhr = null;
var elemRes = null;

function validateFieldsAndCalc(elemAID, elemBID, elemResID)  {

  var a = document.getElementById(elemAID);
  var b = document.getElementById(elemBID);
  elemRes = document.getElementById(elemResID);
  
  var aint = parseInt( a.value, 10 );
  var bint = parseInt( b.value, 10 );
  
  if(isNaN(aint) || isNaN(bint)) {
    alert("ERRO");
    return false;
  }
  else {
    //alert("Ok: Valores = (" + aint + " + " + bint + ")");
    
    
    xhr = new XMLHttpRequest();
    var url = "CalcHandler.ashx";
    xhr.onreadystatechange = processData;
    xhr.open("GET", url, true /* async */);

    xhr.send(null);
    
    return /*true*/ false; // false porque NUNCA queremos postback (pedido feito via AJAX)
  }

}

function processData() {

  if(xhr.readyState == 4 ) { /* DONE */ 
    //alert("yuppi: " + xhr.readyState);
    //alert(xhr.responseText);
    elemRes.value = xhr.responseText;
  }
  

}