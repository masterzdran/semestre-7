﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;



namespace PI.Controls {

  /// <summary>
  /// Summary description for Class1
  /// </summary>
  public class TicTacToeV1x : Control {

    protected override void Render(HtmlTextWriter writer) {
      base.Render(writer);


      for(int i = 0; i < 3; i++) {
        writer.AddAttribute(HtmlTextWriterAttribute.Class, "line");
        writer.RenderBeginTag(HtmlTextWriterTag.Div);
        for(int j = 0; j < 3; j++) {
          writer.AddAttribute(HtmlTextWriterAttribute.Class, "cell"); 
          writer.RenderBeginTag(HtmlTextWriterTag.Span);
          writer.Write("X");
          writer.RenderEndTag();
        }
        writer.RenderEndTag();
      }





    }


  }

}