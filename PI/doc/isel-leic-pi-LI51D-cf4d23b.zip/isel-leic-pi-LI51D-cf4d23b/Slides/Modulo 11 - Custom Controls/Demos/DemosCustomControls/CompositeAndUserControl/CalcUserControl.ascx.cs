﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

public partial class Demos_CompositeAndUserControl_CalcUserControl : System.Web.UI.UserControl
{

  public int A {
    
    get {
      return int.Parse(txtOpA.Text);
    }

    set {
      txtOpA.Text = value.ToString();
    }
  }

  protected void CalcValues(object obj, EventArgs e) {

    Page.Trace.Warn("CalcValues");

    string res = String.Empty;
    try {
      int a = int.Parse(txtOpA.Text);
      int b = int.Parse(txtOpB.Text);
      res = (a + b).ToString();
    }
    catch {
      res = "Error";
    };
    txtRes.Text = res;

  }

}
