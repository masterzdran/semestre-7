﻿using System;
using System.Web;
using System.Web.UI;
using System.Text;


namespace PI.Controls
{
	/// <summary>
	/// Summary description for TicTacToe.
	/// </summary>
	public class TicTacToeV2 : Control, INamingContainer
	{
		protected override void OnPreRender(EventArgs e)
		{
			base.OnPreRender(e);
//			string sCode = @"<script language=javascript>
//				var g_rgbXWentLast = new Object();
//				function OnClickCell(cell, idx) {
//					
//					if (cell.innerText == ' ') {
//						if (g_rgbXWentLast[idx]) {
//							cell.innerText = 'O';
//											
//						} else {
//							cell.innerText = 'Y';
//							
//						}
//						g_rgbXWentLast[idx] = !g_rgbXWentLast[idx];
//					}
////					else
////						cell.innerText = ' ';
//				}
//				</script>";
            Page.ClientScript.RegisterClientScriptInclude(this.GetType().FullName, "TicTacToe.js");
            if (this.Page.IsPostBack)
            {
                Page.ClientScript.RegisterClientScriptBlock(this.GetType(), this.ID,
                    String.Format("<script language='ecmascript'>addGame({0});updateHiddenField({0});</script>", this.ClientID));
            }
		}

		
		protected override void Render(HtmlTextWriter output)
		{
            string []clientState = {"&nbsp;", "&nbsp;","&nbsp;","&nbsp;","&nbsp;","&nbsp;","&nbsp;","&nbsp;","&nbsp;"}; 
            String clientStateStr = String.Empty;
            if(this.Page.IsPostBack) {
                clientStateStr = Page.Request[this.ClientID];
                if(clientStateStr != String.Empty) {
                    int stIdx = clientStateStr.IndexOf('[')+1;

                    String clientStateCells = clientStateStr.Substring(stIdx, clientStateStr.IndexOf(']')- stIdx);
                    clientState = clientStateCells.Split(new char[] { ',', '\''}, StringSplitOptions.RemoveEmptyEntries);
                }
            }
            output.AddAttribute(HtmlTextWriterAttribute.Id, this.ClientID);
            output.RenderBeginTag(HtmlTextWriterTag.Div);

            if(clientStateStr != String.Empty) {
                output.Write(String.Format("<script type='text/ecmascript'>addGame('{0}', {1});</script>", this.ClientID, clientStateStr));
            }


            output.Indent += 2;
            output.AddAttribute(HtmlTextWriterAttribute.Value, clientStateStr);
            output.AddAttribute(HtmlTextWriterAttribute.Type, "hidden");
            output.AddAttribute(HtmlTextWriterAttribute.Name, this.ClientID);
            output.RenderBeginTag(HtmlTextWriterTag.Input);

			output.AddAttribute(HtmlTextWriterAttribute.Border, "2");
			output.RenderBeginTag(HtmlTextWriterTag.Table);
            
			for (int row=0; row<3; row++)
			{
				output.RenderBeginTag(HtmlTextWriterTag.Tr);
				for (int col=0; col<3; col++)
				{
					string clk = string.Format("OnClickCell(this, '{0}', {1})", ClientID, row*3+col);
					output.AddAttribute(
						HtmlTextWriterAttribute.Onclick, clk);
					output.AddStyleAttribute(HtmlTextWriterStyle.Width, "3ex");
					output.RenderBeginTag(HtmlTextWriterTag.Td);
                    String content = clientState[row*3+col];
					output.Write(content == " " ? "&nbsp;" : content);
					output.RenderEndTag();
				}
				output.RenderEndTag();
			}
			output.RenderEndTag();
            output.Indent += 2;
            output.RenderEndTag();
		}
	}
}

