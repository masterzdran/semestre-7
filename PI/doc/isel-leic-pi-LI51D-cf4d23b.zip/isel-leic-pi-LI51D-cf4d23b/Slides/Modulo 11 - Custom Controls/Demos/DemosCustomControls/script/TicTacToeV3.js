﻿
var chars = ['O', 'X'];
//var currentTurn = 0;
var x;


function cellClick() {

  // Obter o elemento actual (do click) a partir
  //  da informação do evento
  var event = getEvent();
  var elem = event.target;
  
  // Acrescentar o current turn (ao avô), se não existir
  if(!elem.parentNode.parentNode.numTurns) {
    elem.parentNode.parentNode.currentTurn = 0;
    elem.parentNode.parentNode.numTurns = 0;
  }

  // "escrever" o char actual no elem
  //elem.appendChild( document.createTextNode( chars[currentTurn] ) );
  if(!elem.hasValue) {
    elem.firstChild.nodeValue = chars[elem.parentNode.parentNode.currentTurn];
    elem.hasValue = true;
    elem.parentNode.parentNode.currentTurn = (++elem.parentNode.parentNode.currentTurn) % 2;
    elem.parentNode.parentNode.numTurns += 1;
    
    var res = elem.parentNode.parentNode.numTurns == 9;
    //alert( "res = " + res );
    if(res) 
    {
      var form = elem.parentNode.parentNode;
      while(form != null && form.tagName != 'FORM')
      {
        form = form.parentNode;
      }
      
      if(form != null) {
        form.submit();
      }
      
      
    }
  }
  
  

}