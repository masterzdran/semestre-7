using System;
using System.Web;


public class CalcHandler : IHttpHandler
{

    #region IHttpHandler Members

    public bool IsReusable
    {
        get { return false; }
    }

    public void ProcessRequest(HttpContext context)
    {
        int x = int.Parse(context.Request["x"]);
        int y = int.Parse(context.Request["y"]);

        int res = x + y;


        if (context.Request.RequestType == "GET")
        {
            context.Response.ContentType = "text/plain";
            context.Response.Output.Write("result = " + res);
            context.Response.Output.Write("\n" + this.GetHashCode());
        }
        else
        {
            context.Response.Output.Write(
                String.Format("<html><body>{0}+{1}={2}</body></html>", x, y, res));


            context.Response.ContentType = "text/html";
        }
        //context.Response.CacheControl = "private";


    }

    #endregion
}
