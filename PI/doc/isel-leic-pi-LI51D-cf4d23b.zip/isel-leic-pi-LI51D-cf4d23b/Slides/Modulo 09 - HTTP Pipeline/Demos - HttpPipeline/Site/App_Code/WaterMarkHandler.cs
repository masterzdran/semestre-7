// --------------------------------------------------------------------------------------------------------------------
// <copyright file="WaterMarkHandler.cs" company="ISEL">
//  Luis Falc�o 
// </copyright>
// <summary>
//   Defines the WaterMarkHandlerFactory type.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

using System.Web;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Text;

#region Factory

public class WaterMarkHandlerFactory : IHttpHandlerFactory {
  private static WaterMarkHandler instance;

  public IHttpHandler GetHandler(HttpContext context, string requestType, string url, string pathTranslated) {

    WaterMarkHandler aux;

    if(instance == null) {
      aux = new WaterMarkHandler("AULA de PI");
      if(aux.IsReusable) {
        instance = aux;
        return instance;
      }
      return aux;
    }
    return instance;
  }

  public void ReleaseHandler(IHttpHandler handler) {
  }
}

#endregion

public class WaterMarkHandler : IHttpHandler {
  private static int cnt = 0;
  private string _text;

  #region Gera��o da imagem com WaterMark

  private Image transform(Image img) {
    Graphics g;
    using(g = Graphics.FromImage(img)) {
      g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
      g.TextRenderingHint = TextRenderingHint.AntiAlias;

      int FontSize = img.Width / 16;

      SizeF size = g.MeasureString(_text,
        new Font("Arial Black", FontSize, FontStyle.Bold, GraphicsUnit.Pixel));

      int Y = (int)((img.Height - size.Height) / 2);
      int X = (int)((img.Width - size.Width) / 2);

      //g.TranslateTransform(img.Width, -10);  //Fudged value
      //g.RotateTransform(90);

      g.DrawString(_text,
        new Font("Arial Black", FontSize, FontStyle.Bold, GraphicsUnit.Pixel),
        new SolidBrush(Color.FromArgb(150, Color.Red)), X, Y);

      g.DrawString(this. GetHashCode().ToString(),
        new Font("Arial Black", FontSize, FontStyle.Bold, GraphicsUnit.Pixel),
        new SolidBrush(Color.FromArgb(150, Color.White)), X, Y + FontSize);

        string wmImage = "~/images/" + "wm.png";
        using(Image imgwm = Image.FromFile(HttpContext.Current.Server.MapPath(wmImage)))
        {
            g.DrawImage(imgwm, 80, 20);
        }
    }
    return img;
  }

  #endregion

  public WaterMarkHandler(string waterMarkText) {
    _text = waterMarkText;
  }

  public WaterMarkHandler() {
    _text = "Benfica";
  }

  #region Interface IHttpHandler

  public void ProcessRequest(HttpContext context) {
      //if(cnt++ % 2 == 0) 
      //    System.Threading.Thread.Sleep(5000);
    context.Response.ContentType = "image/gif";
    string filename = "~/images/" + context.Request.QueryString["Image"];
      filename = context.Server.MapPath(filename);
    Image img;
    
    using(img = Image.FromFile(filename)) {
      transform(img);
      img.Save(context.Response.OutputStream, ImageFormat.Gif);
    }
  }

  public bool IsReusable {
    get {
      return true;
    }
  }

  #endregion

}
