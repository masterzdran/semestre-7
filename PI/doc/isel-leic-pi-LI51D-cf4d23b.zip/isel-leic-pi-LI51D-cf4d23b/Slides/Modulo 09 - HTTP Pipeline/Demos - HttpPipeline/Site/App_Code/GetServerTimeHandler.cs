using System;
using System.Web;


public class GetServerTimeHandler : IHttpHandler
{

    #region IHttpHandler Members

    public bool IsReusable
    {
        get { return true; }
    }

    public void ProcessRequest(HttpContext context)
    {
        context.Response.ContentType = "text/plain";
        context.Response.Write(DateTime.Now.ToString());
        //System.Threading.Thread.Sleep(5000);
    }

    #endregion
}
