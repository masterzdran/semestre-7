using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for TimerModule
/// </summary>
public class TimerModule : IHttpModule
{
    #region IHttpModule Members

    public void Dispose() { }

    public void Init(HttpApplication app)
    {

        app.BeginRequest += new EventHandler(app_BeginRequest);
        app.EndRequest += new EventHandler(app_EndRequest);

    }

    void app_BeginRequest(object sender, EventArgs e)
    {
        HttpContext.Current.Items["tempo"] = DateTime.Now;
    }

    void app_EndRequest(object sender, EventArgs e)
    {
        TimeSpan delta = DateTime.Now.Subtract(
          (DateTime)HttpContext.Current.Items["tempo"]);

        HttpContext.Current.Response.Write("\n\nModule: Tempo de processamento: " + delta.TotalMilliseconds + "<br/>");
        HttpContext.Current.Response.Write("HashCode: " + this.GetHashCode());
    }
    #endregion
}
