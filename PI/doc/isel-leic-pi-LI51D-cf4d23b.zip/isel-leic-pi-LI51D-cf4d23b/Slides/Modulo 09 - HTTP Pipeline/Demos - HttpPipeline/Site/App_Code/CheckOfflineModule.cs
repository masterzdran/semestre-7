using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public class CheckOfflineModule : IHttpModule
{
    public void Init(HttpApplication app)
    {
        app.BeginRequest += new EventHandler(context_BeginRequest);
    }

    void context_BeginRequest(object sender, EventArgs e)
    {
        HttpApplication app = (HttpApplication)sender;
        string fullFileName = app.Server.MapPath(@"~/App_Offline.html");
        if (System.IO.File.Exists(fullFileName))
        {
            HttpContext.Current.Items["endRequest"] = true;
            app.Response.ClearContent();
            app.Response.ClearHeaders();
            app.Response.ContentType = "text/html";
            app.Response.WriteFile(fullFileName);
            app.Response.End();
        }

    }

    public void Dispose()
    {
    }
}
