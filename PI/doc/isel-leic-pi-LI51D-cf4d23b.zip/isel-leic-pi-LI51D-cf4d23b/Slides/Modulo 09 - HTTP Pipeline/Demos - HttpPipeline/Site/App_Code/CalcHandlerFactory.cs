﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

/// <summary>
/// Summary description for CalcHandlerFactory
/// </summary>
public class CalcHandlerFactory: IHttpHandlerFactory
{
    private CalcHandler instance = new CalcHandler();

    public IHttpHandler GetHandler(HttpContext context, string requestType, string url, string pathTranslated)
    {
        return instance;
    }

    public void ReleaseHandler(IHttpHandler handler)
    {
        
    }
}
