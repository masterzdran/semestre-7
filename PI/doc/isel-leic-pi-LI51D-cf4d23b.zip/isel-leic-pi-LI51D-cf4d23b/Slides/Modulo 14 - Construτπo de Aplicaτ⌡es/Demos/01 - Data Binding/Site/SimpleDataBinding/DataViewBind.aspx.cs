using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using System.Data.SqlClient;

namespace DataBindSample
{

    public partial class DataViewBind : System.Web.UI.Page
    {

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            btn.Click += new EventHandler(btn_Click);

            if (!IsPostBack)
            {

                string connStr = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\PUBS.MDF;Integrated Security=True;Connect Timeout=30;User Instance=True";
                using(SqlConnection conn = new SqlConnection(connStr))
                {
                    // Criar um dataSet com duas tabelas da base de dados (Authors e Publishers)
                    DataSet db = new DataSet("pubs");
                    SqlDataAdapter adapterAuthors = new SqlDataAdapter("select * from authors", conn);
                    SqlDataAdapter adapterPublisher = new SqlDataAdapter("select * from publishers", conn);

                    adapterAuthors.Fill(db, "authors");
                    adapterPublisher.Fill(db, "publishers");


                    DataView dv = db.Tables["authors"].DefaultView;
                    //dv.RowFilter = "au_lname like 'G%'";

                    // Associar os dados (tabelas) aos controlos Web
                    //lb1.DataSource = db;
                    lb1.DataSource = dv;
                    lb2.DataSource = db;
                    dg.DataSource = db;

                    dg.DataMember = "publishers";

                    //lb1.DataMember = "authors";
                    lb2.DataMember = "publishers";
                    // como n�o indico o DataMember da dataGrid, esta utiliza a vista por omiss�o

                    lb1.DataTextField = "au_lname";
                    lb1.DataValueField = "au_id";

                    lb2.DataTextField = "pub_name";
                    lb2.DataValueField = "pub_id";

                    this.DataBind();
                }
            }

        }

        private void btn_Click(object sender, EventArgs e)
        {
            // ....
        }
    }
}
