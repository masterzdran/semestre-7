using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace DataBindSample
{
    /// <summary>
    /// Summary description for ObjectArrayListBind.
    /// </summary>
    public partial class ObjectArrayListBind : System.Web.UI.Page
    {

        #region Person Objects Code & Init

        private class Person
        {
            private string id;
            private string firstName;
            private string lastName;

            public string ID
            {
                get
                {
                    return id;
                }
            }
            public string FirstName
            {
                get
                {
                    return firstName;
                }
            }
            public string LastName
            {
                get
                {
                    return lastName;
                }
            }
            public Person(string id, string fn, string ln)
            {
                this.id = id;
                firstName = fn;
                lastName = ln;
            }

            //public override string ToString() {
            //  return FirstName;
            //}

        }

        static Person[] Persons;
        static ObjectArrayListBind()
        {
            ArrayList al = new ArrayList();
            al.Add(new Person("A-C71970F", "Aria", "Cruz"));
            al.Add(new Person("A-R89858F", "Annette", "Roulet"));
            al.Add(new Person("AMD15433F", "Ann", "Devon"));
            al.Add(new Person("ARD36773F", "Anabela", "Domingues"));
            al.Add(new Person("CFH28514M", "Carlos", "Hernadez"));
            al.Add(new Person("CGS88322F", "Carine", "Schmitt"));
            al.Add(new Person("DBT39435M", "Daniel", "Tonini"));
            al.Add(new Person("DWR65030M", "Diego", "Roel"));
            al.Add(new Person("ENL44273F", "Elizabeth", "Lincoln"));
            al.Add(new Person("F-C16315M", "Francisco", "Chang"));
            al.Add(new Person("GHT50241M", "Gary", "Thomas"));

            /* Comentado daqui para a frente, de forma a que a
             * lista das pessoas apareca toda numa p�gina. */

            /*
            al.Add(new Person("H-B39728F", "Helen", "Bennett"));
            al.Add(new Person("HAN90777M", "Helvetius", "Nagy"));
            al.Add(new Person("HAS54740M", "Howard", "Snyder"));
            al.Add(new Person("JYL26161F", "Janine", "Labrune"));
            al.Add(new Person("KFJ64308F", "Karin", "Josephs"));
            al.Add( new Person("KJJ92907F","Karla","Jablonski") );
            al.Add( new Person("L-B31947F","Lesley","Brown") );
            al.Add( new Person("LAL21447M","Laurence","Lebihan") );
            al.Add( new Person("M-L67958F","Maria","Larsson") );
            al.Add( new Person("M-P91209M","Manuel","Pereira") );
            al.Add( new Person("M-R38834F","Martine","Rance") );
            al.Add( new Person("MAP77183M","Miguel","Paolino") );
            al.Add( new Person("MAS70474F","Margaret","Smith") );
            al.Add( new Person("MFS52347M","Martin","Sommer") );
            al.Add( new Person("MGK44605M","Matti","Karttunen") );
            al.Add( new Person("MJP25939M","Maria","Pontes") );
            al.Add( new Person("MMS49649F","Mary","Saveley") );
            al.Add( new Person("PCM98509F","Patricia","McKenna") );
            al.Add( new Person("PDI47470M","Palle","Ibsen") );
            al.Add( new Person("PHF38899M","Peter","Franken") );
            al.Add( new Person("PMA42628M","Paolo","Accorti") );
            al.Add( new Person("POK93028M","Pirkko","Koskitalo") );
            al.Add( new Person("PSA89086M","Pedro","Afonso") );
            al.Add( new Person("PSP68661F","Paula","Parente") );
            al.Add( new Person("PTC11962M","Philip","Cramer") );
            al.Add( new Person("PXH22250M","Paul","Henriot") );
            al.Add( new Person("R-M53550M","Roland","Mendel") );
            al.Add( new Person("RBM23061F","Rita","Muller") );
            al.Add( new Person("SKO22412M","Sven","Ottlieb") );
            al.Add( new Person("TPO55093M","Timothy","O'Rourke") );
            al.Add( new Person("VPA30890F","Victoria","Ashworth") );
            al.Add( new Person("Y-L77953M","Yoshi","Latimer") );
            */
            Persons = (Person[])al.ToArray(typeof(Person));
        }

        #endregion

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            btn.Click += new EventHandler(btn_Click);

            if (!IsPostBack)
            {
                cbl.DataSource = Persons;
                cbl.DataTextField = "FirstName";
                cbl.DataValueField = "ID";

                ddl.DataSource = Persons;
                ddl.DataTextField = "FirstName";
                ddl.DataTextFormatString = "Nome: {0}";
                ddl.DataValueField = "ID";

                GridView1.DataSource = Persons;

                this.DataBind();
                //cbl.DataBind();
                //ddl.DataBind();
            }
        }

        private void btn_Click(object sender, EventArgs e)
        {
            lbl.Text = string.Format("Value: {0}, Index: {1}, Item: {2}",
              cbl.SelectedValue,
              cbl.SelectedIndex,
              cbl.SelectedItem);

            cbl.ClearSelection();
        }

    }
}
