using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class ChangeTheme_aspx : Page
{

	protected void setCurrentTheme(string theme)
	{
		Context.Items["Theme"] = theme;
		Server.Transfer(Request.FilePath);
	}

	protected override void OnPreInit(EventArgs e) {
		string newTheme = (string)Context.Items["Theme"];
	    if (newTheme != null) {
	      this.Theme = (newTheme == "None") ? null: newTheme;
	 	}
		base.OnPreInit(e);
	}
	
	protected void Page_Load(object sender, EventArgs e) {
		if (!IsPostBack)
			this.themeSelect.Text = Page.Theme;
	}

	 
	protected void themeSelect_SelectedIndexChanged(object sender, EventArgs e)
	{
		setCurrentTheme(themeSelect.SelectedValue);
	}
}
