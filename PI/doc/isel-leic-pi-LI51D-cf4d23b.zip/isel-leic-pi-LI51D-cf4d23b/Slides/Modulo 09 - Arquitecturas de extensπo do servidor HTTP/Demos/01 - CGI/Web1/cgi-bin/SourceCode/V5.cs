using System;
using System.Text;
using System.Collections;
using System.IO;

namespace CGI2 {

  /*
   * Esta vers�o do CGI mostra a utiliza��o de cookies
   * 
   */
  class V5 {

    [STAThread]
    static void Main(string[] args) {
      ProcessRequest();
    }

    public static void ProcessRequest() {

      StringBuilder content = new StringBuilder("<html><body>Ola, sou um CGI gerado pela vers�o 5 do cgi <em>CGI2.exe</em><br/><br/>");

      content.Append(String.Format("<a href='{0}' >cgi</a>", System.Environment.GetEnvironmentVariable("SCRIPT_NAME")));
      content.Append("<br/>");

      // Cookies
      content.Append("<h1>Cookies enviados pelo browser</h1>");
      content.AppendFormat("{0}: {1}", "HTTP_COOKIE", System.Environment.GetEnvironmentVariables()["HTTP_COOKIE"]);

      content.Append("<br/>");

      // Todas as vars de ambiente
      content.Append("<h1>Valor de todas as vari�veis de ambiente</h1>");

      content.Append("<table><tbody><tr><th>Key</th><th>Value</th></tr>");
      foreach(DictionaryEntry de in System.Environment.GetEnvironmentVariables()) {
        content.AppendFormat("<tr><td>{0}</td><td>{1}</td></tr>", de.Key, de.Value);
      }
      content.Append("</tbody></table>");

      content.Append("</body></html>");

      // Escrever o conte�do da resposta para uma memory stream
      MemoryStream m = new MemoryStream();
      StreamWriter res = new StreamWriter(m);
      res.WriteLine(content.ToString());
      res.Flush();

      // Escrever os headers
      System.Console.WriteLine("HTTP/1.1 200 OK");
      System.Console.WriteLine("Content-Type: text/html; charset=utf-8");
        // Cookie ==> n�o persistente <==
      System.Console.WriteLine("Set-Cookie: a=b; path=/CGI/cgi-bin/");
        // Cookie ==> persistente <==
      System.Console.WriteLine("Set-Cookie: type=persistente; path=/CGI/cgi-bin/; expires=Monday Oct 22 2007 12:31:18 GMT+0100 (GMT Daylight Time)");

      System.Console.WriteLine(string.Format("Content-Length: {0}", m.Length));
      System.Console.WriteLine();

      // Escrever o conte�do da memory stream
      Stream console = System.Console.OpenStandardOutput();
      m.WriteTo(console);

    }
  }
}
