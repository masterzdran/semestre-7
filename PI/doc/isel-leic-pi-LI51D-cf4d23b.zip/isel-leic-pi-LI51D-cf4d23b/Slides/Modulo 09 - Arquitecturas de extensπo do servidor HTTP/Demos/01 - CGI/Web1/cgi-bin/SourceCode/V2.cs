using System;
using System.IO;

namespace CGI2 {

  class V2 {

    [STAThread]
    static void Main(string[] args) {
      ProcessRequest();
    }

    public static void ProcessRequest() {

      //string content = "<html><body>Ol�, sou um CGI gerado pela vers�o 2 do cgi <em>CGI2.exe</em></body></html>";
      //string content = "<html><body>Ol�, sou um CGI gerado pela vers�o 2 do cgi <em>CGI2.exe</em></body></html>";

      // Escrever o conte�do da resposta para uma memory stream
      MemoryStream m = new MemoryStream();
      StreamWriter res = new StreamWriter(m);
      //res.WriteLine(content);
      res.WriteLine("<html><body>Ol&aacute;, sou um CGI gerado pela vers�o ");
      res.WriteLine("2 do cgi <em>CGI2.exe</em></body></html>");
      res.Flush();

      // Escrever os headers
      System.Console.WriteLine("HTTP/1.1 200 OK");
      //System.Console.WriteLine("Content-Type: text/html");
      System.Console.WriteLine("Content-Type: text/html; charset=utf-8");

      System.Console.WriteLine(string.Format("Content-Length: {0}", m.Length));
      System.Console.WriteLine();

      // Escrever o conte�do da memory stream
      Stream console = System.Console.OpenStandardOutput();
      m.WriteTo(console);

    }
  }
}
