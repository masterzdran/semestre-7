using System;
using System.Text;
using System.Collections;
using System.IO;

namespace CGI2 {

  /*
   * Esta vers�o do CGI apresenta o valor das vari�veis de ambiente existentes
   * Nas vari�veis de ambiente encontramos a indica��o do tipo de pedido (GET ou POST)
   * No caso do comando ser GET os dados do formul�rio v�m na queryString, se por
   *   outro lado o comando for POST os dados do formul�rio t�m que ser lido atrav�s
   *   do standardInput 
   * 
   *   QUESTION? Quando � que sei que � para terminar de ler?!
   *   ANSWER: Atrav�s da vari�vel de ambiente CONTENT_LENGTH
   * 
   *  NOTA: Neste exemplo vai-se explorar o m�todo GET
   * 
   */
  class V3 {

    [STAThread]
    static void Main(string[] args) {
      ProcessRequest();
    }

    public static void ProcessRequest() {

      StringBuilder content = new StringBuilder("<html><body>Ola, sou um CGI gerado pela vers�o 3 do cgi <em>CGI2.exe</em><br/><br/>");

      // Vars de ambiente mais importantes
      content.Append("<h1>Vari�veis de ambiente mais importantes</h1>");
      string[] coolestEnvs = { "REQUEST_METHOD", "QUERY_STRING", "CONTENT_LENGTH", "HTTP_USER_AGENT", "HTTP_REFERER"  };
      content.Append("<table><tbody><tr><th>Key</th><th>Value</th></tr>");
      foreach(string env in coolestEnvs) {
        content.AppendFormat("<tr><td>{0}</td><td>{1}</td></tr>", env, System.Environment.GetEnvironmentVariables()[env]);
      }
      content.Append("</tbody></table>");
      content.Append("<br/>");
      // Todas as vars de ambiente
      content.Append("<h1>Valor de todas as vari�veis de ambiente</h1>");
      content.Append("<table><tbody><tr><th>Key</th><th>Value</th></tr>");
      foreach(DictionaryEntry de in System.Environment.GetEnvironmentVariables()) {
        content.AppendFormat("<tr><td>{0}</td><td>{1}</td></tr>", de.Key, de.Value);
      }
      content.Append("</tbody></table>");

      content.Append("</body></html>");

      // Escrever o conte�do da resposta para uma memory stream
      MemoryStream m = new MemoryStream();
      StreamWriter res = new StreamWriter(m);
      res.WriteLine(content.ToString());
      res.Flush();

      // Escrever os headers
      System.Console.WriteLine("HTTP/1.1 200 OK");
      System.Console.WriteLine("Content-Type: text/html; charset=utf-8");
        // Cookie ==> n�o persistente <==
      //System.Console.WriteLine("SET-COOKIE: type=nao persistente; path=/cgi-bin");
        // Cookie ==> persistente <==
      //System.Console.WriteLine("SET-COOKIE: type=persistente; path=/cgi-bin; expires=domingo, 25 de Julho de 2010 11:31:07");

      System.Console.WriteLine(string.Format("Content-Length: {0}", m.Length));
      System.Console.WriteLine();

      // Escrever o conte�do da memory stream
      Stream console = System.Console.OpenStandardOutput();
      m.WriteTo(console);

    }
  }
}
