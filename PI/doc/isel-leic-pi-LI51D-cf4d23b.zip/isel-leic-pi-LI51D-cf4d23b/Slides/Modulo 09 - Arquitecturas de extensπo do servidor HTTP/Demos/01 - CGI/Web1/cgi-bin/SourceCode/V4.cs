using System;
using System.Text;
using System.Collections;
using System.IO;

namespace CGI2 {

  /*
   * Esta vers�o do CGI apresenta o valor das vari�veis de ambiente existentes
   * Nas vari�veis de ambiente encontramos a indica��o do tipo de pedido (GET ou POST)
   * No caso do comando ser GET os dados do formul�rio v�m na queryString, se por
   *   outro lado o comando for POST os dados do formul�rio t�m que ser lido atrav�s
   *   do standardInput 
   * 
   *   QUESTION? Quando � que sei que � para terminar de ler?!
   *   ANSWER: Atrav�s da vari�vel de ambiente CONTENT_LENGTH
   * 
   *  NOTA: Neste exemplo vai-se explorar o m�todo POST
   * 
   */
  class V4 {

    [STAThread]
    static void Main(string[] args) {
      ProcessRequest();
    }

    public static void ProcessRequest() {

      // In�cio do documento
      StringBuilder content = new StringBuilder("<html><body>Ola, sou um CGI gerado pela vers�o 4 do cgi <em>CGI2.exe</em><br/><br/>");

      string method = System.Environment.GetEnvironmentVariables()["REQUEST_METHOD"] as string;

      // Se o m�todo for GET, responde-se com um formul�rio (login)
      if(method.ToLower().Equals("get")) {
        // HINT: Se calhar ler este conte�do de um ficheiro seria boa ideia ! (quais ser�o os cuidados a ter?!)
        content.Append(
@"
<form method='POST' action='v4.exe' >
  Nome: <input type='text' name='nome' /><br/>
  Password: <input type='password' name='passw' /><br/>
  <input type='submit' /> <input type='reset' />
</form>
");

      // Se o m�todo for POST, apresenta-se o valor dos campos do formul�rio
      } else if(method.ToLower().Equals("post")) {
        
        IDictionary formData = ReadFormData();
        content.AppendFormat("Ol� {0}, a sua password �: {1}<br/>", formData["nome"], formData["passw"]);


      } else {
        content.Append("<b>Error:</b> Request Method not supported....");
      }

      // Fim do documento
      content.Append("</body></html>");

      // Escrever o conte�do da resposta para uma memory stream
      MemoryStream m = new MemoryStream();
      StreamWriter res = new StreamWriter(m);
      res.WriteLine(content.ToString());
      res.Flush();

      // Escrever os headers
      System.Console.WriteLine("HTTP/1.1 200 OK");
      System.Console.WriteLine("Content-Type: text/html; charset=utf-8");
      System.Console.WriteLine(string.Format("Content-Length: {0}", m.Length));
      System.Console.WriteLine();

      // Escrever o conte�do da memory stream
      Stream console = System.Console.OpenStandardOutput();
      m.WriteTo(console);

    }


    /// <summary>
    /// Este m�todo retorna um contentor associativo com os dados
    ///  do formul�rio. Name --> Value
    /// </summary>
    /// <returns></returns>
    public static IDictionary ReadFormData() {
      IDictionary res = new Hashtable();

      int length = int.Parse((string)Environment.GetEnvironmentVariables()["CONTENT_LENGTH"]);

      byte[] buffer = new byte[length];
      Console.OpenStandardInput().Read(buffer, 0, length);

      string str = System.Text.UTF8Encoding.UTF8.GetString(buffer);
      string[] strArray = str.Split('&');
      foreach(string s in strArray) {
        string key = s.Substring(0, s.IndexOf('='));
        string value = s.Substring(s.IndexOf('=')+1);
        res.Add(key, value);
      }

      return res;
      
    }
  }
}
