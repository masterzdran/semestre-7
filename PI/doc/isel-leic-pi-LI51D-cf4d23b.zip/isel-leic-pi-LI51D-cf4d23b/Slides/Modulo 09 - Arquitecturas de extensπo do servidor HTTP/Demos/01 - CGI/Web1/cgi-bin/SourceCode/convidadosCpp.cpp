#define _CRT_SECURE_NO_DEPRECATE
#include <iostream>
using namespace std;

void main() {
   char *env;
   cout<<"Content-type: text/html"<<endl<<endl; 
   cout<<"<html>"<<endl;
   cout<<"<head><title>CGI livro de convidados escrito em C++</title></head>"<<endl; 
   cout<<"<body><h1> Bem vindo ao meu livro de convidados </h1>"<<endl; 
   env = getenv("REQUEST_METHOD");
   cout <<"REQUEST_METHOD: " << (env != NULL ? env : "") << "<br />" << endl; 
   env = getenv("QUERY_STRING");
   cout <<"QUERY_STRING: " << (env != NULL ? env : "") << "<br />" << endl; 
   cout << "</body></html>" << endl;
}
