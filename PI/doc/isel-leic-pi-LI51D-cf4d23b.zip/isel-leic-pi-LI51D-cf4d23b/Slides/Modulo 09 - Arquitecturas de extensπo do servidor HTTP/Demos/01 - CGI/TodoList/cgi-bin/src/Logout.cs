using System;
using System.Collections;
using System.IO;

namespace TodoList {

  /// <summary>
  /// CGI que realiza a opera��o de logout
  ///   - Remover o cookie enviando um cookie com 
  ///      data de expira��o inferior � data actual.
  /// </summary>
  class Logout {

    public static void Main(String[] args) {
      TodoList.Logout.ProcessRequest();
    }

    public static void ProcessRequest() {

      try {
        // Escrever os headers
        System.Console.WriteLine("HTTP/1.1 200 OK");
        System.Console.WriteLine("Content-Type: text/plain;");
        // Enviar cookie que faz o logout
        System.Console.WriteLine("Set-Cookie: useName={0}; path=/CGITodoList/; expires={1}", "cguedes", "Wed, 25 Oct 2006 00:00:01 GMT");
        System.Console.WriteLine("Content-Length: 0");
        System.Console.WriteLine();

      } catch(Exception exp) {
        // Indicar erro no caso de ocorrer uma excep��o
        System.Console.WriteLine("HTTP/1.1 500 Internal Server Error");
        System.Console.WriteLine();
        System.Console.WriteLine(exp.StackTrace);
      }
    }
  
  }
}
