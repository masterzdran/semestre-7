/******************************************************************
  TODO LIST CODE
******************************************************************/

var loginStatus;
var txtUserName;
var txtPassword;
var loadingImage;

function $get(id) {
  return document.getElementById(id);
}

// Ponto de entrada da aplica��o
function main() {

  loginStatus = $get("LoginStatus");
  txtUserName = $get("txtUserName");
  txtPassword = $get("txtPassword");
  loadingImage = $get("LoadingImage");
  
  txtUserName.focus();
  attachClickEvent($get("btnLogin"), doLoginAction);
}

function doLogoutAction() {
  loadingImage.className = "";  
  
  var http = new XMLHttpRequest();
  http.open("get", "cgi-bin/logout.exe", true);
  http.onreadystatechange = function() {
    if(http.readyState == 4 && http.status == 200) {
      $get("Login").className = "";               // Mostrar o login
      $get("Content").className = "Hidden";       // Esconder o conte�do
      $get("Logout").className = "Hidden";        // Esconde o logout
      txtUserName.value = txtPassword.value = "";
      loginStatus.innerHTML = "";
      loadingImage.className = "Hidden";
    }
  }
  http.send();
  
}

function doLoginAction() {  
  if(txtUserName.value == "" || txtPassword.value == "") {
    loginStatus.className = "loginError";
    loginStatus.innerHTML = "Deve indicar o nome e a password.";
    return;
  }
  
  loadingImage.className = "";  // mostrar o loading....

  var http = new XMLHttpRequest();
  var queryString = "userName=" + txtUserName.value + "&password=" + txtPassword.value;
  http.open("get", "cgi-bin/login.exe?" + queryString, true);
  http.setRequestHeader("foo", "bar");
  http.onreadystatechange = function() {
    if(http.readyState == 4 && http.status == 200) {
      loadingImage.className = "Hidden";  // esconder o loading....
    
      var res = eval("(" + http.responseText + ")");
      if(res.loginResult == false) {
        // Erro no login
        loginStatus.className = "loginError";
        loginStatus.innerHTML = "Utilizador ou password inv�lidas.";
        return;
      }
    
      // Sucesso no login
      loginStatus.className = "loginSuccess";
      loginStatus.innerHTML = "Login efectuado com sucesso.";
      setTimeout(function() {
          // Esconder o login
          var login = $get("Login");
          login.className = "Hidden";
          
          // mostrar o logout
          var Logout = $get("Logout");
          Logout.className = "";
          
          // Mostrar o conte�do
          var content = $get("Content");
          content.className = "";
        }, 1000
      );
    }
  }
  http.send();
}




/***********************************************************
  Fun��es utilit�rias  
********************************************************** */

// Esta fun��o verifica se existe a fun��o addEventListener, 
//   de acordo com o DOM- N�vel 2, para registar o evento onclick
function attachClickEvent(domElement, callback) {
  if(domElement.addEventListener) {
    // usar DOM
    domElement.addEventListener("click", callback, false);
  }
  else {
    // IE
    domElement.onclick = callback;
  }
}
