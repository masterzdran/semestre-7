using System;
using System.IO;

namespace CGI2 {

  class V1 {

    static void Main(string[] args) {
      ProcessRequest();
    }


    public static void ProcessRequest() {

      string content = "<html><body>Ol�, sou um CGI gerado pela vers�o 2.</body></html>";

      // Escrever os headers
      System.Console.WriteLine("HTTP/1.1 200 OK");
      System.Console.WriteLine("Content-Type: text/html");
      System.Console.WriteLine(
        string.Format("Content-Length: {0}", content.Length)
      );
      System.Console.WriteLine();

      // Escrever o conte�do
      System.Console.WriteLine(content);

    }
  }
}
