#include <iostream>
using namespace std;


int main() {
  int nBytes = 10;
  cout << "HTTP/1.1 200 OK" << endl;
  cout << "Content-type: text/plain" << endl;
  cout << "Content-length: " << nBytes << endl;
  cout << endl;
  cout << "Ola mundo!";

  return 1;
}