using System;

class OlaMundo {

  public static void Main(String[] args) {
    int nBytes = 10;
    System.Console.WriteLine("HTTP/1.1 200 OK");
    System.Console.WriteLine("Content-type: text/plain");
    System.Console.WriteLine(String.Format("Content-length: {0}", nBytes));
    System.Console.WriteLine();
    System.Console.WriteLine("Ola mundo!");
  }

}