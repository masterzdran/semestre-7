#include <iostream>

using namespace std;


int main() {

  //cout << "HTTP/1.1 200 OK" << endl;
  cout << "Content-Type: text/html" << endl;
  cout << "Content-Length: 41" << endl;
  cout << endl;
  cout << "<html><body>Ola, sou um CGI</body></html>" << endl;

  return 0;

}