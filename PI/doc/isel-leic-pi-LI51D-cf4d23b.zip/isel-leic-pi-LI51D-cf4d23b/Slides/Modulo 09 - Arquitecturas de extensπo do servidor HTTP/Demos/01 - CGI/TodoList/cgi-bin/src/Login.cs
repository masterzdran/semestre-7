using System;
using System.Collections;
using System.IO;

namespace TodoList {

  /// <summary>
  /// CGI que realiza a opera��o de login
  ///   - envia um cookie de sess�o (com o nome do utilizador)
  ///   - verifica se existe base de dados (ficheiro de texto)
  ///      de TODOs para este utilizador. Se n�o existir, cria uma.
  ///   - Nome da base de dados: <userName>.todo
  /// </summary>
  class Login {

    public static void Main(String[] args) {
      TodoList.Login.ProcessRequest();
    }

    #region Load Login Data

    private static string AppPath {
      get {
        return @"D:\cguedes\ISEL\Docencia\1s0607\PI\Samples\CGI - Aula 25_10_2006\TodoList";;
      }
    }

    private static string UsersPath {
      get {
        return string.Format(@"{0}\data\users.txt", AppPath);
      }
    }

    private static Hashtable users = new Hashtable();
    private static void LoadUsers() {
      users.Add("cguedes", "foo");
      users.Add("lfalcao", "bar");

      /*
      StreamReader sr = new StreamReader(UsersPath, true);
      using(sr) {
        while(sr.BaseStream.CanRead) {
          string[] strs = sr.ReadLine().Split(' ');
          users.Add(strs[0], strs[1]);
        }
      }
      */
    }

    #endregion

    public static void ProcessRequest() {

      try {
        // Realiza a opera��o de login
        LoadUsers();

        // Obt�m dados do pedido
        IDictionary requestData = GetRequestData();
        string userName = (string)requestData["userName"];
        string password = (string)requestData["password"];

        // Escrever o conte�do da resposta para uma memory stream
        MemoryStream m = new MemoryStream();
        StreamWriter res = new StreamWriter(m);

        bool loginOK =
          users.ContainsKey(userName) &&
          ((string)users[userName]).Equals(password);

        res.WriteLine("{0} loginResult: {1} {2}", "{", loginOK ? "true" : "false", "}");
        res.Flush();

        // Escrever os headers
        System.Console.WriteLine("HTTP/1.1 200 OK");
        System.Console.WriteLine("Content-Type: text/plain; charset=utf-8");
        if(loginOK) {
          // Enviar cookie que identifica o utilizador
          System.Console.WriteLine("Set-Cookie: useName={0}; path=/CGITodoList/; expires={1}", userName, "Fri, 27 Oct 2006 00:00:01 GMT");
        }
        System.Console.WriteLine(string.Format("Content-Length: {0}", m.Length));
        System.Console.WriteLine();

        // Escrever o conte�do da memory stream
        Stream console = System.Console.OpenStandardOutput();
        m.WriteTo(console);

      } catch(Exception exp) {
        // Indicar erro no caso de ocorrer uma excep��o
        System.Console.WriteLine("HTTP/1.1 500 Internal Server Error");
        System.Console.WriteLine();
        System.Console.WriteLine(exp.StackTrace);
      }

    }


    /// <summary>
    /// Este m�todo retorna um contentor associativo com os dados
    ///  do formul�rio. Name --> Value
    /// Suporta pedidos GET e POST.
    /// </summary>
    public static IDictionary GetRequestData() {
      IDictionary res = new Hashtable();
      string strPairsNameValue = string.Empty;

      string requestMethod = Environment.GetEnvironmentVariable("REQUEST_METHOD").ToLower();
      if(requestMethod.Equals("get")) {
        strPairsNameValue = Environment.GetEnvironmentVariable("QUERY_STRING");
      } 
      else if(requestMethod.Equals("post")) {
        int length = int.Parse((string)Environment.GetEnvironmentVariables()["CONTENT_LENGTH"]);
        byte[] buffer = new byte[length];
        Console.OpenStandardInput().Read(buffer, 0, length);
        strPairsNameValue = System.Text.UTF8Encoding.UTF8.GetString(buffer);
      }

      if(!strPairsNameValue.Equals(string.Empty)) {
        string[] strArray = strPairsNameValue.Split('&');
        foreach(string s in strArray) {
          string key = s.Substring(0, s.IndexOf('='));
          string value = s.Substring(s.IndexOf('=') + 1);
          res.Add(key, value);
        }
      }

      return res;

    }

  
  }
}
