using System;
using System.Net.Sockets;
using System.IO;
using System.Text;
using Logging;
using System.Collections.Specialized;
using System.Collections;
using System.Diagnostics;

namespace HTTPServer
{
	/// <summary>
	/// Classe que cont�m todo o contexto do pedido e da resposta HTTP. 
	/// � criada uma inst�ncia desta classe por cada pedido. Essa inst�ncia � passada como 
	/// par�metro a todas a entidades intervenientes no processo de atendimento de um pedido 
	/// HTTP.
	/// </summary>
	public class HttpContext
	{
		private Socket _sock;
		private StringDictionary _reqHeaders = new StringDictionary();
		private Hashtable _responseHeaders = new Hashtable();
		private string _command;
		private Uri _reqUrl;
		private string _protocolVersion;
		private Stream _inputStream;
		private Stream _outputStream;

		private TextReader _reader;
		private TextWriter _writer;


		/// <summary>
		/// Construtor que recebe o Socket com a liga��o estabelecida com o cliente
		/// </summary>
		/// <param name="s"></param>
		public HttpContext(Socket s)
		{
			_sock = s;
		}


		/// <summary>
		/// L� todo o header do Pedido HTTP e cria todo o contexto do pedido que o objecto 
		/// vai disponibilizar.
		/// </summary>
		public void ParseRequest() 
		{
			LingerOption lo = new LingerOption(true, 10);
			//_sock.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.NoDelay, 1);
			//_sock.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.Linger, lo);

			_inputStream = new NetworkStream(_sock, FileAccess.Read, false);
			_outputStream = new NetworkStream(_sock, FileAccess.Write, false);
			

			_reader = new StreamReader(_inputStream, Encoding.Default, true);
			_writer = new StreamWriter(_outputStream, Encoding.ASCII);
			
			//_writer = new StringWriter();
			_writer.NewLine = "\r\n";
			string requestLine = _reader.ReadLine();
			Log.WriteLine(TraceLevel.Verbose, "Request Received: \n{0}", requestLine);			

			string []requestLineTokens = requestLine.Split(new char[] {' '});
			_command = requestLineTokens[0].Trim();
			_reqUrl = new Uri("http://localhost" + requestLineTokens[1].Trim());
			_protocolVersion = requestLineTokens[2].Trim();

			string fieldLine;
			while( (fieldLine = _reader.ReadLine()) != "") 
			{
				int idx = fieldLine.IndexOf(":");
				string key = fieldLine.Substring(0, idx).Trim();
				string val = fieldLine.Substring(idx+1, fieldLine.Length-idx-1).Trim();

				_reqHeaders.Add(key, val);
				Log.WriteLine(TraceLevel.Verbose, "{0}:{1}", key, val);
			}

			Log.WriteLine(TraceLevel.Verbose, "----------------------------");			
		}


		/// <summary>
		/// Comando HTTP recebido (GET, POST, HEAD, etc)
		/// </summary>
		public String Command
		{
			get { return _command; }
		}

		/// <summary>
		/// URL (completo) pedido pelo cliente
		/// </summary>
		public Uri RequestUrl
		{
			get { return _reqUrl; }
		}


		/// <summary>
		/// TextReader para leitura de car�cteres da Stream do Socket (s� utilizado em comandos POST)
		/// </summary>
		public TextReader Reader
		{
			get { return _reader; }
		}

		/// <summary>
		/// TextReader para escrita de car�cteres na Stream Socket (s� utilizado em comandos POST)
		/// Utilizado em todas as respostas com car�cteres (texto)
		/// </summary>
		public TextWriter Writer
		{
			get { return _writer; }
		}

		/// <summary>
		/// Stream de escrita (de bytes) do Socket
		/// </summary>
		public Stream OutputStream 
		{
			get { return _outputStream; }
		}

		public Stream InputStream 
		{
			get { return _inputStream; }
		}


		public Socket Socket
		{
			get { return _sock; }
		}



		public string UrlExtension
		{
			get { 
				string []segs = _reqUrl.Segments;
				return segs[segs.Length-1].Split(new char[] {'.'})[1];
			}
		}

        public string ProtocolVersion 
		{
			get { return _protocolVersion; }
		}

		public StringDictionary RequestHeaders 
		{
			get { return _reqHeaders; }
		}

		public IDictionary ResponseHeaders 
		{
			get { return _responseHeaders; }
		}

		public int ServerPort
		{
			get { return HTTPServer.HttpServer.Port; }
		}

		public string ServerRoot
		{
			get { return HTTPServer.HttpServer.ServerRoot; }
		}

		/*
		public void SendError(int errorCode) 
		{
			HttpRuntime.SendErrorResponse(errorCode, _writer);
		}
		*/

		
		public void SendResponseLine(int statusCode) 
		{
			HttpRuntime.SendSuccessfullResponse(statusCode, this);
		}
		

		public void SendHeaderFields() 
		{
			HttpRuntime.SendHeaderFields(this);
		}

	}
}
