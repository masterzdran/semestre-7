using System;
using System.Net.Sockets;
using System.Net;
using Logging;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Configuration;


namespace HTTPServer {
  /// <summary>
  /// Ponto de entrada da aplica��o. Cria um socket e espera por liga��es dos clientes.
  /// Por cada liga��o estabelecida chama o m�todo HttpRuntime.ProcessRequest() e 
  /// volta a esperar nova liga��o. 
  /// </summary>
  sealed public class HttpServer {
    private HttpServer() { }

    /// <summary>
    /// Porto onde o servidor espera pedidos
    /// </summary>
    public static UInt16 Port = UInt16.Parse(ConfigurationSettings.AppSettings["ServerPort"]);

    /// <summary>
    /// Directoria raiz do servidor Web no Filesystem
    /// </summary>
    public static string ServerRoot = ConfigurationSettings.AppSettings["ServerRootPath"];

    /// <summary>
    /// Ponto de entrada da aplica��o. 
    /// </summary>
    /// <param name="args">
    /// Pode receber como primeiro argumanto, o porto onde o servidor deve acaitar liga��es.
    /// <see cref="Port"/>
    /// </param>
    public static void Main(String[] args) {
      Console.WriteLine(
      typeof(HttpServer).Assembly.FullName);
      Console.WriteLine(
      typeof(HttpServer).FullName);
      Log.WriteLine(TraceLevel.Verbose, "Http Server Started");
      if(args.Length == 1) {
        try {
          Port = UInt16.Parse(args[0]);
        }
        catch(Exception) { }
      }


      Socket s = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
      EndPoint ep = new IPEndPoint(IPAddress.Any, Port);
      s.Bind(ep);
      s.Listen(5);
      Console.WriteLine("Server listening on port: {0}, Root Directory: '{1}'", Port, ServerRoot);
      while(true) {
        Socket sclient = s.Accept();
        Log.WriteLine(TraceLevel.Verbose, String.Format("Request Accepted from: {0}", sclient.RemoteEndPoint));
        HttpRuntime.ProcessRequest(sclient);
      }
    }
  }
}
