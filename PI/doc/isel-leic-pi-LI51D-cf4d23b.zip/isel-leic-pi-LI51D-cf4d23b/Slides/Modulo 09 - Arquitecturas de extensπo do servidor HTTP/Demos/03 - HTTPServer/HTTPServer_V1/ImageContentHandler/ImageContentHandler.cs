using System;
using System.IO;
using System.Text;

namespace HTTPServer.ContentHandlers
{
	/// <summary>
	/// Summary description for ImageContentHandler.
	/// </summary>
	public class ImageContentHandler: ContentHandler
	{
		public ImageContentHandler()	{ }

		protected override void DoGet(HttpContext context) {

			string fileName = context.ServerRoot + context.RequestUrl.LocalPath.Replace('/', '\\');
			FileStream stream = null;
			try 
			{ 
				//File f = new File(
				stream = new FileStream(fileName, FileMode.Open);
				
				context.ResponseHeaders["Content-Type"] = "image/" + context.UrlExtension;
				FileInfo fi = new FileInfo(fileName);
				context.ResponseHeaders["Content-Length"] = fi.Length.ToString();
				context.SendResponseLine(200);
				context.SendHeaderFields();

				int read;
				byte [] buf = new byte[4096];
				do 
				{
					read = stream.Read(buf, 0, buf.Length);
					context.OutputStream.Write(buf, 0, read);
				} while(read == buf.Length);
				
			} 
			catch(FileNotFoundException ) 
			{
				throw new HttpException(404);
			}
			finally 
			{
				if(stream == null)
					stream.Close();
			}
		}
	}
}
