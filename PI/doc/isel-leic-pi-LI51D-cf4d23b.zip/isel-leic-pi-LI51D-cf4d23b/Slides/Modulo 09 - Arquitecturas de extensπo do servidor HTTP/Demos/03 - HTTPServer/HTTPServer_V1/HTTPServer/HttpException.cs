using System;

namespace HTTPServer
{
	/// <summary>
	/// Summary description for HttpException.
	/// </summary>
	public class HttpException : Exception
	{
		private int _httpErrorCode;

		public HttpException(int code): this(code, null) 
		{ }

		public HttpException(int code, Exception inner): base(code.ToString(), inner)
		{
			_httpErrorCode = code;
		}

		public int HttpErrorCode 
		{
			get { return _httpErrorCode; }
		}
	}
}
