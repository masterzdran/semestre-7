using System;
using System.Globalization;
using System.IO;
using System.Xml;
using System.Diagnostics;

namespace Logging
{
	/// <summary>
	/// This is a listener for the DebugLog component that stores the debug information
	/// in the XML format
	/// </summary>
	/// <remarks>
	/// In order to use this listener it must be included in the App.Config file of the main project
	/// The template document that is referenced in the App.Config sould have this format:
	/// <DebugInformation entriesBeforeSaving="" entriesPerFile="" logFilesLocation="" weeksToKeep="" maxSpaceInDisk=""/>
	/// entriesBeforeSaving defines when a backup of the current file is saved to disk
	/// entriesPerFile defines when a new file shouldbe created
	/// logFileLocation defines the root directory for the log files; under this directory a new directory 
	/// is created for every week of every year (Week200342 - week number 42 of the year 2003) 
	/// containing the debug log files for that week
	/// weeksToKeep defines the minimum number of weeks that must be kept
	/// maxSpaceInDisk defines the maximum amount of space (in bytes) that the debug log files can occupy;
	/// when this space is exceeded the component tries to delete old weeks, always respecting the 
	/// minimum number of weeks that must be kept. This means that the maximum space in disk can be exceeded.
	/// </remarks>

	public class XMLTraceListener : LogTraceListener
	{
		
		/// <summary>
		/// Document containing the log file
		/// </summary>
		private XmlDocument _logDocument = new XmlDocument();
		/// <summary>
		/// Document element of the log file - _logDocument.DocumentElement
		/// </summary>
		private XmlNode _logInformation;
		/// <summary>
		/// Name of the file appearing in the App.Config that contains the log configuration
		/// </summary>
		//private string _strConfigurationFileName;
		/// <summary>
		/// Name of the current log file being created
		/// </summary>
		private string _strCurrentFileName;
		/// <summary>
		/// Full path to the log's root directory
		/// </summary>
		private string _logFilesLocation;
		/// <summary>
		/// Number of entries a log file can contain
		/// </summary>
		private int _nEntriesPerFile;
		/// <summary>
		/// Number of entries the current log file has
		/// </summary>
		private int _nDebugEntriesInFile;
		/// <summary>
		/// Number of entries that are written before savinga backup to disk
		/// </summary>
		private int _nEntriesBeforeSaving;
		/// <summary>
		/// Current number of entries; when this number mod _nEntriesBeforeSaving equals zero the file is saved
		/// </summary>
		private int _nDebugEntries;
		/// <summary>
		/// Space in disk that log files can occupy
		/// </summary>
		private int _maxSpaceInDisk;
		/// <summary>
		/// Number of weeks that must be kept in disk even if this means exceeding the maximum
		/// space in disk
		/// </summary>
		private int _weeksToKeep;

		/// <summary>
		/// Load the configuration file and initialise log parameters
		/// </summary>
		/// <param name="fileName">File containing the log configuration</param>
		/// <remarks>
		/// If the file is not found the configuration parameters are set to default values
		/// _nEntriesBeforeSaving = 10;
		/// _nEntriesPerFile = 1000;
		/// _logFilesLocation = @"C:\DeLaRue\DebugLog\01\Logs";
		/// _maxSpaceInDisk = 5242880; // 5MB
		/// _weeksToKeep = 2;
		/// If the root directory does not exist it is created
		/// If the log files exceed the maximum space in disk a directory is deleted, if possible
		/// A new log file is created as well as a new directory, if necessary
		/// </remarks>
		public XMLTraceListener(string pars)
		{
			//_strConfigurationFileName = fileName;
			try
			{
				XmlElement newElement = _logDocument.CreateElement(String.Empty,"DebugInformation", String.Empty);
				_logDocument.AppendChild(newElement);
				_logInformation = _logDocument.DocumentElement;

				setProperties(pars);
				if (Directory.Exists(_logFilesLocation) == false)
					Directory.CreateDirectory(_logFilesLocation);

				// Check log space in disk; if necessary try to delete a directory
				if (CheckDirectorySize(_logFilesLocation) > _maxSpaceInDisk)
					DeleteLogDirectories();
				ResetLogDocument();

			}
			catch(Exception e) 
			{
				GC.SuppressFinalize(this);
				Trace.Listeners.Remove(this);
				Log.WriteLine(TraceLevel.Warning, "[XMLTraceListener.XMLTraceListener]: Removed myself from Trace Listeners because the following exception ocurred: {0}{1}", Environment.NewLine, e);
			}
		}
			
		/// <summary>
		/// The log file is saved
		/// </summary>
		~XMLTraceListener()
		{
			SaveLogFile(false);
			Dispose(false);
		}

		/// <summary>
		/// Saves the log file
		/// </summary>
		/// <param name="createNewFile">Distinguishes between a backup save (false) and 
		/// a final save (true)</param>
		/// <remarks>
		/// The log file is saved
		/// If this is a final save (number of entries per file has been reached) the size of the
		/// log files is checked and, if necessary and possible, a directory is deleted; also a new 
		/// log file is created as well as a new directory, if necessary
		/// </remarks>
		private void SaveLogFile(bool createNewFile)
		{
			_logDocument.Save(_strCurrentFileName);
			_nDebugEntries = 0;
			// Check if it is necessary to create a new file name
			if (createNewFile == true)
			{
				// Check log space in disk; if necessary try to delete a directory
				if (CheckDirectorySize(_logFilesLocation) > _maxSpaceInDisk)
					DeleteLogDirectories();
				ResetLogDocument();
			}
		}

		/// <summary>
		/// Create a new log file and, if necessary, a new directory
		/// </summary>
		/// <remarks>
		/// Find the current week number; if the corresponding directory does not exist it is created
		/// Find a new file name (dd-mm hhmmss,mmm.xml)
		/// Reset the xml document in memory
		/// </remarks>
		private void ResetLogDocument()
		{
			DateTime now = DateTime.Now;
			// Find week of year and build directory name

			CultureInfo      CI       = CultureInfo.CurrentCulture;
			Calendar         Cal      = CI.Calendar;
			CalendarWeekRule CWR      = CI.DateTimeFormat.CalendarWeekRule;
			DayOfWeek        FirstDOW = CI.DateTimeFormat.FirstDayOfWeek;

			int weekOfYear = Cal.GetWeekOfYear(now, CWR, FirstDOW);

			//			int dayOfYear = now.DayOfYear;
			//			int weekOfYear = (dayOfYear%7==0)?(dayOfYear/7):((dayOfYear/7)+1);

			string weekOfYearStr = (weekOfYear<10)?("0"+weekOfYear.ToString()):(weekOfYear.ToString());
			string directoryName = _logFilesLocation+@"\Week"+now.Year.ToString()+weekOfYearStr;
			// Build file name
			string fileName = String.Format(@"{0}\{1:dd-MM HHmmss,fff}.xml", directoryName, now);			
			// Check if this directory is already created; if not create it
			if (Directory.Exists(directoryName) == false)
				Directory.CreateDirectory(directoryName);

			_nDebugEntriesInFile = 0;
			_logInformation.RemoveAll();
			_strCurrentFileName = fileName;
		}

		/// <summary>
		/// Create a new entry in the log file
		/// </summary>
		/// <param name="message">The message to be logged</param>
		/// <param name="category">The debug level and the component associated with the message (level[:component])</param>
		/// <remarks>
		/// Create a new element in the xml document in memory; the element has an attribute
		/// setting its category and its value is the message to be logged
		/// If the number of entries per file was reached save the file and create a new one
		/// If the number of entriesbefore saving was reached save a backup of the file
		/// </remarks>
		public override void Write(string message, string category)
		{
			try
			{
				string[] parameters;
				string level;
				string component;
				if (category.IndexOf(":") > 0)
				{
					parameters = category.Split(":".ToCharArray(), 2);
					level = parameters[0];
					component = parameters[1];
				}
				else
				{
					level = category;
					component = "None";
				}

				int finalIndex = message.IndexOf("]");
				string time = message.Substring(1, finalIndex-1);
				string logMessage = message.Substring(finalIndex+3);
				XmlElement newElement = _logDocument.CreateElement(String.Empty,"Entry", String.Empty);
				XmlAttribute newCategoryAttribute = _logDocument.CreateAttribute(String.Empty,"category",String.Empty);
				XmlAttribute newOwnerAttribute = _logDocument.CreateAttribute(String.Empty, "owner", String.Empty);
				XmlAttribute newTimeAttribute = _logDocument.CreateAttribute(String.Empty, "time", String.Empty);
				XmlText newTextNode = _logDocument.CreateTextNode(logMessage);

				newElement.AppendChild(newTextNode);
				newOwnerAttribute.Value = component;
				newElement.Attributes.Append(newOwnerAttribute);
				newCategoryAttribute.Value = level;
				newElement.Attributes.Append(newCategoryAttribute);
				newTimeAttribute.Value = time;
				newElement.Attributes.Append(newTimeAttribute);
				_logInformation.AppendChild(newElement);

				++_nDebugEntries;
				++_nDebugEntriesInFile;
				if (_nDebugEntriesInFile == _nEntriesPerFile)
					SaveLogFile(true);
				else
					if ((_nDebugEntries % _nEntriesBeforeSaving) == 0)
					SaveLogFile(false);
			}
			catch (Exception)
			{
				// Do nothing
			}
		}

		/// <summary>
		/// Create a new entry in the log file
		/// </summary>
		/// <param name="message">The message to be logged</param>
		/// <remarks>
		/// Call the method Write(string message, string category)
		/// </remarks>
		public override void Write(string message)
		{
			Write(message, "None"); 
		}

		/// <summary>
		/// Create a new entry in the log file
		/// </summary>
		/// <param name="message">The message to be logged</param>
		/// <param name="category">The debug level and the component associated with the message (level[:component])</param>
		/// <remarks>
		/// Call the method Write(string message, string category)
		/// </remarks>
		public override void WriteLine(string message, string category)
		{
			Write(message/* + Environment.NewLine*/, category);			
		}

		/// <summary>
		/// Create a new entry in the log file
		/// </summary>
		/// <param name="message">The message to be logged</param>
		/// <remarks>
		/// Call the method Write(string message, string category)
		/// </remarks>
		public override void WriteLine(string message)
		{
			WriteLine(message/* + Environment.NewLine*/, "None"); 
		}
	
		/// <summary>
		/// Release used resources
		/// </summary>
		/// <param name="disposing">true to release managed and unmanaged resources; false to release only unmanaged</param>
		protected override void Dispose(bool disposing)
		{
			base.Dispose(disposing);
		}

		/// <summary>
		/// Check the size of the directory
		/// </summary>
		/// <param name="path">Directory to be checked for size</param>
		/// <returns>The size of the directory (including the size of its subdirectories)</returns>
		/// <remarks>
		/// This function is recursive
		/// If the directory has subdirectories the function is called or every one of them
		/// If any subdirectory can't be accessed its value is 0
		/// In the end add the size of every file to the size of the subdirectories and return
		/// </remarks>
		private static long CheckDirectorySize(string path)
		{
			// Analyze all subdirectories
			long sizeOfDirectories = 0;
			try
			{
				String[] subdirectories = Directory.GetDirectories(path);
				foreach (String current in subdirectories)
				{
					sizeOfDirectories += CheckDirectorySize(current);
				}
			}
			catch
			{
				// Can't access this subdirectory... return 0
				return 0;
			}

			// All the subdirectories are searched; get the total
			// size of all files under this directory
			long fileBytes = 0;
			foreach (String current in Directory.GetFiles(path))
			{
				FileInfo info = new FileInfo(current);
				fileBytes += info.Length;
			}

			return sizeOfDirectories + fileBytes;
		}

		/// <summary>
		/// Delete the oldest directory, if possible
		/// </summary>
		/// <remarks>
		/// Determine how many log directories exist under the root directory; if there are more
		/// directpries than the number of weeks that must be kept delete the oldest directory
		/// </remarks>
		private void DeleteLogDirectories()
		{
			String[] subdirectories = Directory.GetDirectories(_logFilesLocation);
			if (subdirectories.Length > _weeksToKeep)
				Directory.Delete(subdirectories[0],true);
		}

		public int EntriesBeforeSaving
		{
			get
			{
				return _nEntriesBeforeSaving;
			}
			set
			{
				_nEntriesBeforeSaving=value;
			}
		}

		public int EntriesPerFile
		{
			get
			{
				return _nEntriesPerFile;
			}
			set
			{
				_nEntriesPerFile=value;
			}
		}

		public string LogFilesLocation
		{
			get
			{
				return _logFilesLocation;
			}
			set
			{
				_logFilesLocation=value;
			}
		}

		public int MaxSpaceInDisk
		{
			get
			{
				return _maxSpaceInDisk;
			}
			set
			{
				_maxSpaceInDisk=value;
			}
		}

		public int WeeksToKeep
		{
			get
			{
				return _weeksToKeep;
			}
			set
			{
				_weeksToKeep=value;
			}
		}
		
		
		
	}
}
