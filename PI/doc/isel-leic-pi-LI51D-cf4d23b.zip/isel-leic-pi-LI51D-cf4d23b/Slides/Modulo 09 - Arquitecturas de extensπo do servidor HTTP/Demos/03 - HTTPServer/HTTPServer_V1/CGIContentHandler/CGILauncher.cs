using System;
using System.Diagnostics;
using System.IO;
using System.Threading;
using System.Collections.Specialized;

namespace HTTPServer
{
	/// <summary>
	/// Summary description for CGILauncher.
	/// </summary>
	public class CGILauncher
	{
		private Process _process;
		private TextReader _processStdin;
		private int _bytes2ReadFromStdIn = 0;
		private TextWriter _processStdout;
		private TextWriter _processStderr;
		

		public CGILauncher()
		{
			_process = new Process();
			_process.StartInfo.UseShellExecute = false;
			_process.StartInfo.CreateNoWindow = false;
			_process.StartInfo.RedirectStandardInput = true;
			_process.StartInfo.RedirectStandardOutput = true;
			_process.StartInfo.RedirectStandardError = true;
			

		}

		public void SetStandardInput(TextReader processStdin, int bytes2read) 
		{
			_processStdin = processStdin;
			_bytes2ReadFromStdIn = bytes2read;

		}

		public TextWriter StandardOutput 
		{
			get { return _processStdout; }
			set { _processStdout = value; }
		}

		public StringDictionary EnvironmentVariables 
		{
			get { return _process.StartInfo.EnvironmentVariables; }
		}


		public TextWriter StandardError 
		{
			get { return _processStderr; }
			set { _processStderr = value; }
		}



		public void Execute(string cgiPathName) 
		{
			/// +++ Launch exceptions if StandardOutput, StandardInput and EnviromentVariavles
			/// properties haven't been set.
			_process.StartInfo.FileName = cgiPathName;
			_process.Start();


			StreamCopier stdinCopier = new StreamCopier(_processStdin, _process.StandardInput, _bytes2ReadFromStdIn, true);
			ThreadPool.QueueUserWorkItem(new WaitCallback(copyStandardInput2Process), stdinCopier);

			

			if(_processStderr != null) 
			{
				StreamCopier stderrCopier = new StreamCopier(_process.StandardError, _processStderr, false);
				ThreadPool.QueueUserWorkItem(new WaitCallback(copyStandardOutputFromProcess), stderrCopier);
			}

			
			// Use the current thread to copy the StandardOutput
			StreamCopier stdoutCopier = new StreamCopier(_process.StandardOutput, _processStdout, false);
			
			//ThreadPool.QueueUserWorkItem(new WaitCallback(copyStandardOutputFromProcess), stdinCopier);
			stdoutCopier.Copy();
			/// ??? Is necessary????
			/// 
			_processStdout.Flush();
			_process.WaitForExit();
			_process.Close();
		}

		private void copyStandardInput2Process(object obj) 
		{
			StreamCopier copier = (StreamCopier)obj;
			copier.Copy();
		}


		private void copyStandardOutputFromProcess(object obj) 
		{
			StreamCopier copier = (StreamCopier)obj;
			copier.Copy();
		}




		private class StreamCopier 
		{
			private TextReader _reader; 
			private TextWriter _writer;
			private int _bytes2Copy;
			private bool _closeWriterOnEnd;


			public StreamCopier(TextReader reader, TextWriter writer, bool closeWriterOnEnd) 
				: this(reader, writer, -1, closeWriterOnEnd)
			{	}

			public StreamCopier(TextReader reader, TextWriter writer, int bytes2Copy, bool closeWriterOnEnd)  
			{
				_reader = reader;
				_writer = writer;
				
				//if(bytes2Copy < 0)
				//	throw new ArgumentException("bytes2Copy must be >= 0");
				_bytes2Copy = bytes2Copy;
				_closeWriterOnEnd = closeWriterOnEnd;
				
			}

			public void Copy() 
			{
				/// This should not be done like this. The TextReader and the bytesCount shoul be
				/// received as parameters (possible race condition!!!)
				char []buf = new char[1024];

				if(_bytes2Copy >= 0) 
				{
					while(_bytes2Copy > 0) 
					{
						int read2Buf = _bytes2Copy > buf.Length ? buf.Length : _bytes2Copy;
						int read = _reader.ReadBlock(buf, 0, read2Buf);
						_bytes2Copy -= read;
						_writer.Write(buf, 0, read);
					}
				} 
				else 
				{
					int read;
					do 
					{
						read = _reader.ReadBlock(buf, 0, buf.Length);
						_writer.Write(buf, 0, read);
					} while(read == buf.Length);
					
				}
				if(_closeWriterOnEnd)
					_writer.Close();
			}
		}
	}
}
