using System;
using System.Text;
using System.Collections.Generic;
using System.Net.Sockets;
using System.Net;
using System.Threading;

namespace BerkleySocket
{
    class EchoClient
    {
        public string Send(string message)
        {
            using(Socket clientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp))
            {
                // Establishing connection to endpoint
                clientSocket.Connect(new IPEndPoint(IPAddress.Loopback, 8080));
                // Encoding and sending message
                Console.WriteLine("Sending message...");
                byte[] encodedMsg = Encoding.UTF8.GetBytes(message);
                clientSocket.Send(encodedMsg);
                // Receiving echoed message
                byte[] echoBuffer = new byte[1024];
                int echoBufferSize = clientSocket.Receive(echoBuffer);
                // Decode and return message
                return Encoding.UTF8.GetString(echoBuffer, 0, echoBufferSize);
            }

        }
    }
}
