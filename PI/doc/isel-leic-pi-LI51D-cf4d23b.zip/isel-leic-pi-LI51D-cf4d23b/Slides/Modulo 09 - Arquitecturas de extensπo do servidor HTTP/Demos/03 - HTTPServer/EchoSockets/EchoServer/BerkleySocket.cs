using System;
using System.Text;
using System.Collections.Generic;
using System.Net.Sockets;
using System.Net;
using System.Threading;

namespace BerkleySocket
{
    class RequestHandler
    {
        private Socket connection;

        public RequestHandler(Socket connection) { this.connection = connection; }

        public void Process()
        {
            using (connection)
            {
                byte[] buffer = new byte[1024];
                int bufferSize = connection.Receive(buffer);
                Console.WriteLine("Echoing {0}", Encoding.UTF8.GetString(buffer, 0, bufferSize));
                connection.Send(buffer, bufferSize, SocketFlags.None);
            }
        }
    }

    class EchoServer
    {
        public void Run()
        {
            using (Socket listeningSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp))
            {
                listeningSocket.Bind(new IPEndPoint(IPAddress.Loopback, 8080));
                listeningSocket.Listen(10);
                while (true)
                {
                    Socket connectionSocket = listeningSocket.Accept();
                    RequestHandler handler = new RequestHandler(connectionSocket);
                    new Thread(new ThreadStart(handler.Process)).Start();
                }
            }
        }
    }
}
