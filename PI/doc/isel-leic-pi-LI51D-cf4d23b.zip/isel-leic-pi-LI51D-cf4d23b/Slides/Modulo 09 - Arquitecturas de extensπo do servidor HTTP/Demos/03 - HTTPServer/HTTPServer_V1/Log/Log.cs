using System;
using System.Diagnostics;
using System.Collections;

namespace Logging
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	public sealed class Log
	{
		public static TraceSwitch _LogSwitch = new TraceSwitch("Log", "The Log Trace Switch");

		private static bool _LoggingToConsole;
		private static long _EntriesId = -1;
		private static long _UniqueEntriesId = 0;

		/// <summary>
		/// Can't create instances
		/// </summary>
		private Log() { }

		private static TraceListener registredInLog(Type t) 
		{
			foreach(TraceListener tl in Trace.Listeners) 
			{
				if(tl.GetType() == t) 
				{
					return tl;
				}
			}
			return null;
		}

		public static TraceListener[] GetListeners(Type t) 
		{
			ArrayList al = new ArrayList();
			foreach(TraceListener tl in Trace.Listeners) 
			{
				if(tl.GetType() == t) 
				{
					al.Add(tl);
				}
			}
			return (TraceListener[])al.ToArray(typeof(TraceListener));
		}

		static Log() { 
			try 
			{
				_LoggingToConsole = registredInLog(typeof(ConsoleTraceListener)) != null;
			} 
			catch(Exception) { 
				/// +++
			}
		}

		public static TraceLevel Level 
		{
			get { return _LogSwitch.Level; }
			set { 
				_LogSwitch.Level = value; 
				OnLogLevelChanged();
				string message = String.Format("############ Log Level Set to {0, -8} #####################{1}", _LogSwitch.Level, Environment.NewLine);
				writeTrace(message, TraceLevel.Info, -1);
			}
		}

		public static bool LogToConsole
		{
			get
			{
				return _LoggingToConsole;
			}
			set
			{
				if(_LoggingToConsole == value)
					return;
				
				_LoggingToConsole = !_LoggingToConsole;
				if(_LoggingToConsole == false) 
				{
					TraceListener ctl = registredInLog(typeof(ConsoleTraceListener));
					Trace.Listeners.Remove(ctl);
					return;
				}
				Trace.Listeners.Add(new ConsoleTraceListener());
			}
		}


		/// <summary>
		/// Id for log entries with undefined Id
		/// </summary>
		public static long EntriesId 
		{
			get { return _EntriesId; }
			set { 
				_EntriesId = value; 
				if(_UniqueEntriesId < value)
					_UniqueEntriesId = value;
			
			}
		}

		public static long SetNextUniqueEntriesId() 
		{
			return _EntriesId = _UniqueEntriesId++;
		}

		
		public static void WriteLine(TraceLevel level, string s) 
		{
			Write(level, _EntriesId, s + Environment.NewLine);
		}

		public static void WriteLine(TraceLevel level, long entryId, string s) 
		{
			Write(level, entryId, s + Environment.NewLine);
		}


		public static void WriteLine(TraceLevel level, string s, params object[]args) 
		{
			Write(level, _EntriesId, s + Environment.NewLine, args);
		}

		public static void WriteLine(TraceLevel level, long entryId, string s, params object[]args) 
		{
			Write(level, entryId, s + Environment.NewLine, args);
		}

		public static void Write(TraceLevel level, string s, params object[]args) 
		{
			Write(level, _EntriesId, String.Format(s,args)); 		
		}

		public static void Write(TraceLevel level, long entryId, string s, params object[]args) 
		{
			Write(level, entryId, String.Format(s,args));
		}


		public static void Write(TraceLevel level, string s) 
		{
			Write(level, _EntriesId, s);
		}
		public static void Write(TraceLevel level, long entryId, string s) 
		{
			if(_LogSwitch.Level >= level) 
			{
				writeTrace(s, level, entryId); 
			}
		}

		public static void WriteLineIf(bool cond, TraceLevel level, string s, params object[]args) 
		{
			if(cond)
				Write(level, _EntriesId, String.Format(s,args)); 		
		}

		public static void WriteLineIf(bool cond, TraceLevel level, long entryId, string s, params object[]args) 
		{
			if(cond)
				Write(level, entryId, String.Format(s,args));
		}


		public static void WriteLineIf(bool cond, TraceLevel level, string s) 
		{
			if(cond)
				Write(level, _EntriesId, s);
		}


		public static void WriteIf(bool cond, TraceLevel level, string s, params object[]args) 
		{
			if(cond)
				Write(level, _EntriesId, String.Format(s,args)); 		
		}

		public static void WriteIf(bool cond, TraceLevel level, long entryId, string s, params object[]args) 
		{
			if(cond)
				Write(level, entryId, String.Format(s,args));
		}


		public static void WriteIf(bool cond, TraceLevel level, string s) 
		{
			if(cond)
				Write(level, _EntriesId, s);
		}



		#region ------------------------- Public events ------------------------------
		/// <summary>
		/// Event Fires when a Log message is written
		/// </summary>
		public static LogEventHandler LogMessage;

		/// <summary>
		/// Event Fires when the Log level changes
		/// </summary>
		public static LogEventHandler LogLevelChanged;


		#endregion ------------------------- Public events ------------------------------


		#region ------------------------- Private methods ------------------------------
		private static void OnLogMessage(string message, TraceLevel level, DateTime date, long entryId) 
		{
			if(LogMessage != null) 
				LogMessage(new LogMessageEventArgs(message, level, date, entryId));
		}

		private static void OnLogLevelChanged() 
		{
			if(LogLevelChanged != null) 
				LogLevelChanged(new LogLevelChangedEventArgs(_LogSwitch.Level));
		}


		/*

		private static void writeTrace(string message) 
		{
			Trace.Write(message);
			OnLogMessage(message, "");

		}
		*/

		private static void writeTrace(string message, TraceLevel level, long entryId) 
		{
			DateTime now = DateTime.Now;

			string time = String.Format("{0} - {1}:{2,-3}",  now.ToShortDateString(), now.ToLongTimeString(), now.Millisecond);
			string logMessage = String.Format("[{0}]: {1}", time, message);

			Trace.Write(logMessage, level.ToString());
			OnLogMessage(message, level, now, entryId);
		}
			
		#endregion ------------------------- Private methods ------------------------------
	}

	/// <summary>
	/// 
	/// </summary>
	public delegate void LogEventHandler(EventArgs args);

	/// <summary>
	/// EventArgs derived type to pass as argument to LogMessage event.
	/// This type has Message property with the Log written Message
	/// </summary>
	[Serializable]
	public class LogMessageEventArgs: EventArgs 
	{
		private string _message;
		private TraceLevel _level;
		private DateTime _date;
		long _entryId; 


		public LogMessageEventArgs(string message, TraceLevel level, DateTime date, long entryId) 
		{
			_message = message;
			_level = level;
			_date = date;
			_entryId = entryId;
		}

		//public LogMessageEventArgs(string message, DateTime date) : this(message, date, "")
		//{
		//}

		public TraceLevel TraceLevel 
		{
			get { return _level; }
		}


		public DateTime Date 
		{
			get { return _date; }
		}

		public string Message 
		{
			get { return _message; }
		}

		public long EntryId
		{
			get { return _entryId; }
		}
	}

	/// <summary>
	/// EventArgs derived type to pass as argument to LogLevelChanged event.
	/// This type has the new LogLevel 
	/// </summary>
	[Serializable]
	public class LogLevelChangedEventArgs: EventArgs 
	{
		public readonly TraceLevel LogLevel;
		public LogLevelChangedEventArgs(TraceLevel level) 
		{
			LogLevel = level;
		}
	}

}
