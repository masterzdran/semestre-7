using System;
using System.IO;
using System.Text;

namespace HTTPServer.ContentHandlers
{
	/// <summary>
	/// Summary description for HtmlContentHandler.
	/// </summary>
	public class HtmlContentHandler: ContentHandler
	{
		public HtmlContentHandler()	{ }

		protected override void DoGet(HttpContext context) {
			string fileName = context.ServerRoot + context.RequestUrl.LocalPath.Replace('/', '\\');
			StreamReader reader = null;
            try
            {
                //File f = new File(
                reader = new StreamReader(fileName);

                context.ResponseHeaders["Content-Type"] = "text/html";
                FileInfo fi = new FileInfo(fileName);
                context.ResponseHeaders["Content-Length"] = fi.Length.ToString();
                context.SendResponseLine(200);
                context.SendHeaderFields();

                int read;
                char[] buf = new char[1024];
                do
                {
                    read = reader.Read(buf, 0, buf.Length);
                    context.Writer.Write(buf, 0, read);
                } while (read == buf.Length);



            }
            catch (FileNotFoundException)
            {
                throw new HttpException(404);
            }
            catch (Exception e)
            {
                throw;
            }

			finally 
			{
				if(reader != null)
					reader.Close();
			}
		}
	}
}
