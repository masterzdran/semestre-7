using System;
using System.Net.Sockets;
using System.Net;
using System.Threading;
using System.IO;

namespace TcpSocket
{
    class RequestHandler
    {
        private TcpClient connection;

        public RequestHandler(TcpClient connection) { this.connection = connection; }

        public void Process()
        {
            using (connection)
            {
                Stream connectionStream = connection.GetStream();
                StreamReader input = new StreamReader(connectionStream);
                string message = input.ReadLine();
                Console.WriteLine("Echoing {0}", message);
                StreamWriter output = new StreamWriter(connectionStream);
                output.WriteLine(message);
                output.Flush();
            }
        }
    }

    class EchoServer
    {
        public void Run()
        {
            TcpListener listeningSocket = null;
            try
            {
                listeningSocket = new TcpListener(new IPEndPoint(IPAddress.Loopback, 8080));
                listeningSocket.Start(10);
                while (true)
                {
                    TcpClient connectionSocket = listeningSocket.AcceptTcpClient();
                    RequestHandler handler = new RequestHandler(connectionSocket);
                    new Thread(new ThreadStart(handler.Process)).Start();
                }
            }
            finally { listeningSocket.Stop(); }
        }
    }
}
