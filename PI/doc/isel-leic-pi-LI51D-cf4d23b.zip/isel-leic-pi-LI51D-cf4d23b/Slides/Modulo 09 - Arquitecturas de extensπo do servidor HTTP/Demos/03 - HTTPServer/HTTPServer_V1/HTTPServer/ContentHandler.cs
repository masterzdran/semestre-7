using System;
using System.Collections.Generic;
using Utils;
using System.Configuration;
using System.Web.Configuration;

namespace HTTPServer.ContentHandlers
{
	/// <summary>
	/// Summary description for ContentHandler.
	/// </summary>
	public abstract class ContentHandler
	{     
		public static ContentHandler GetContentHandler(HttpContext context) 
		{
            return ContentHandlerFactory.GetContentHandler(context.UrlExtension, context.Command);            
		}


		public void ProcessRequest(HttpContext context) 
		{
			switch(context.Command) 
			{
				case "GET": this.DoGet(context); break;
				case "POST": this.DoPost(context); break;
				case "HEAD": this.DoHead(context); break;
				default: throw new HttpException(501);
			}
		}

		protected virtual void DoGet(HttpContext context) 
		{
			throw new HttpException(501);
		}

		protected virtual void DoPost(HttpContext context) 
		{
			throw new HttpException(501);
		}

		protected virtual void DoHead(HttpContext context) 
		{
			throw new HttpException(501);
		}        
	
	}
}
