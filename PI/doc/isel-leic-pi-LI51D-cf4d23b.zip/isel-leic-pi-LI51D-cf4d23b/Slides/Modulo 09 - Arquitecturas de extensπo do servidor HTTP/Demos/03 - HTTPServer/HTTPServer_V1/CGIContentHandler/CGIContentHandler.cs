using System;
using System.IO;
using System.Text;
using System.Collections.Specialized;
using System.Net.Sockets;
using System.Net;

namespace HTTPServer.ContentHandlers
{
    /// <summary>
    /// Summary description for CGIContentHandler.
    /// </summary>
    public class CGIContentHandler : ContentHandler
    {
        private CGILauncher _launcher = new CGILauncher();
        private int _contentLength = 0;
        public CGIContentHandler() { }


        private void LaunchCGI(HttpContext context)
        {
            StringDictionary envVars = _launcher.EnvironmentVariables;

            // Server Related Environment Variables
            IPEndPoint local = (IPEndPoint)context.Socket.LocalEndPoint;
            IPAddress localAddr = local.Address;
            envVars["SERVER_NAME"] = Dns.GetHostByAddress(localAddr).HostName;
            envVars["LOCAL_ADDR"] = localAddr.ToString();
            envVars["SERVER_PORT"] = local.Port.ToString();
            envVars["SERVER_SOFTWARE"] = "ISEL Web Server";
            envVars["SERVER_PROTOCOL"] = "HTTP/1.1";
            envVars["GATEWAY_INTERFACE"] = "CGI/1.1";
            envVars["GATEWAY_INTERFACE"] = "CGI/1.1";

            envVars["CONTENT_LENGTH"] = _contentLength.ToString();

            envVars["REQUEST_METHOD"] = context.Command;

            try
            {

                _launcher.SetStandardInput(context.Reader, _contentLength);
                _launcher.StandardOutput = context.Writer;
                _launcher.Execute(context.ServerRoot + context.RequestUrl.LocalPath.Replace('/', '\\'));
            }
            catch (FileNotFoundException e)
            {
                throw new HttpException(404);
            }
            finally
            {
                context.ResponseHeaders["Connection"] = "Close";
            }
        }


        protected override void DoPost(HttpContext context)
        {
            StringDictionary envVars = _launcher.EnvironmentVariables;
            string contentLen = context.RequestHeaders["Content-Length"] as string;
            _contentLength = int.Parse(contentLen);

            LaunchCGI(context);

        }

        protected override void DoGet(HttpContext context)
        {
            _launcher.EnvironmentVariables["QUERY_STRING"] = context.RequestUrl.Query;
            LaunchCGI(context);

        }
    }
}
