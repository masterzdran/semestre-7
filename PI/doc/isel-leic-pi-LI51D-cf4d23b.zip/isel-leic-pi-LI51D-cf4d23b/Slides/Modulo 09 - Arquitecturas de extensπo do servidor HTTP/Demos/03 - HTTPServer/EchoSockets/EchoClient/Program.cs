using System;
using System.Collections.Generic;
using System.Text;
using System.Net.Sockets;
using System.Net;
using System.IO;

class Program
{
    //static void Main(string[] args)
    //{
    //    while (true)
    //    {
    //        // Collect input
    //        Console.WriteLine("Enter string to echo:");
    //        string msg = Console.ReadLine();
    //        if (msg.Length == 0) 
    //            return;
    //        // Sending message and receiving echo
    //        // string echoedMsg = new BerkleySocket.EchoClient().Send(msg);
    //        string echoedMsg = new TcpSocket.EchoClient().Send(msg);
    //        // Display echo
    //        Console.WriteLine("Received '{0}'", echoedMsg);
    //        Console.Write("Press enter to continue");
    //        Console.ReadLine();
    //    }
    //}
}
