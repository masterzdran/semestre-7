using System;
using System.IO;
using Logging;
using System.Xml.Serialization;
using System.Diagnostics;

namespace Utils
{
	/// <summary>
	/// Summary description for SerializationHelper.
	/// </summary>
	sealed public class SerializationHelper
	{
		private const string TEMP_FILES_EXTENSION = ".tmp";

		private SerializationHelper() {	}


		public static object DeserializeObjectFromXmlDataFile(string dataFile, Type type) 
		{
			object obj = null;
			FileStream fs = null;
//			bool exists = File.Exists(dataFile);
//			if(exists) 
//			{
				try 
				{
					fs = new FileStream(dataFile, FileMode.Open, FileAccess.Read);
					XmlSerializer ser = new XmlSerializer(type);
					obj = ser.Deserialize(fs);
				} 
				catch(Exception e) 
				{
					// Se alguma coisa correr mal escrever em Log
					Log.WriteLine(TraceLevel.Warning, "[SerializationHelper.DeserializeObjectFromXmlDataFile]- Could not deserialize configuration file, bacause of the following Exception:{0}{1}", Environment.NewLine, e);
					//throw e;
				} 
				finally 
				{
					if(fs != null)
						fs.Close();
				}
//			} 
//			else 
//			{
//				Log.WriteLine(TraceLevel.Warning, "SerializationHelper.DeserializeObjectFromXmlDataFile] - Could not find file \"{0}\"!", dataFile);
//			}
			return obj;
		}


		public static void SerializeObjectToXmlDataFile(string dstFileName, object objToSer) 
		{
			string tmpFileName = dstFileName+TEMP_FILES_EXTENSION;

			//FileInfo file = new FileInfo(dstFileName);
			
			//DirectoryInfo dir = file.Directory;
			DirectoryInfo dir = Directory.GetParent(dstFileName);
			if(dir.Exists== false)
				dir.Create();
			dir = null;

			FileStream fs = null;
			try 
			{
				XmlSerializer ser = new XmlSerializer(objToSer.GetType());
				fs = new FileStream(tmpFileName, FileMode.Create, FileAccess.Write);
				ser.Serialize(fs, objToSer);

				fs.Close();
				fs = null;
				File.Delete(dstFileName);
				File.Move(tmpFileName, dstFileName);
				tmpFileName = null;
			} 
			catch(Exception e) 
			{
				// Se alguma coisa correr mal escrever em Log
				Log.WriteLine(TraceLevel.Warning, "[SaveObjectToDataFile.SaveObjectToDataFile]- Could not save object of type {0} to Data File '{1}', bacause of the following Exception:{2}{3}",
					objToSer.GetType().Name, dstFileName, Environment.NewLine, e.ToString());
			} 
			finally 
			{
				if(fs != null)
					fs.Close();
			}
		}

	}
}
