using System;
using System.Diagnostics;
using System.Reflection;

namespace Logging
{
	/// <summary>
	/// Summary description for TraceListenerBase.
	/// </summary>
	public class LogTraceListener : TextWriterTraceListener
	{
		public LogTraceListener()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		protected void setProperties(String pars)
		{
			
			// Extract the parameters
			string delimiters = "=,";
			string []parsArray = pars.Split(delimiters.ToCharArray());

			Type thisType = this.GetType();
			for(int i = 0; i < parsArray.Length; i += 2) 
			{
				PropertyInfo prop = thisType.GetProperty(parsArray[i].Trim());
				if(prop == null)
					continue;
				object val = parsArray[i+1];
				Type dstType = prop.PropertyType.UnderlyingSystemType;
				val = Convert.ChangeType(val, dstType);
				prop.SetValue(this, val , null);
			}
		}
	}
}
