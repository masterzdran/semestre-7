using System;
using System.Net.Sockets;
using System.Net;
using System.Threading;
using System.IO;

namespace TcpSocket
{
    class EchoClient
    {
        public string Send(string message)
        {
            
            using (TcpClient connection = new TcpClient())
            {
                connection.Connect(new IPEndPoint(IPAddress.Loopback, 8080));
                Stream connectionStream = connection.GetStream();
                // Sending message
                Console.WriteLine("Sending message...");
                StreamWriter output = new StreamWriter(connectionStream);
                output.WriteLine(message);
                output.Flush();
                // Receiving echoed message
                StreamReader input = new StreamReader(connectionStream);
                return input.ReadLine();
            }

        }
    }
}
