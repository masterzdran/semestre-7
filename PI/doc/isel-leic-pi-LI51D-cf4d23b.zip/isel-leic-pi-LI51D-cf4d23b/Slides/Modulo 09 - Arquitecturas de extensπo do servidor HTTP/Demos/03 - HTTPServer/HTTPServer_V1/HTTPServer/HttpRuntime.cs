using System;
using System.Text;
using System.Collections.Specialized;
using System.Threading;
using HTTPServer.ContentHandlers;
using System.IO;
using Logging;
using System.Collections;
using System.Diagnostics;
using System.Net.Sockets;

namespace HTTPServer
{
	/// <summary>
	/// Classe utilit�ria (apenas com m�todos de classe) que implementa o protocolo HTTP.
	/// Cria uma thread para cada cliente que fa�a um pedido <see cref="ProcessRequest"/> e 
	/// <see cref="InternalProcessRequest"/>. Essa Thread mant�m-se activa at� que a liga��o 
	/// com o cliente (Socket) seja fechada.
	/// </summary>
	public sealed class HttpRuntime
	{
		/// <summary>
		/// Dicion�rio com os c�digos de erro do protocolo HTTP e respectivas strings a 
		/// enviar na linha de status das respostas HTTP (1� linha da resposta).
		/// Este dicion�rio � iniciado no construtor de classe <see cref="static HttpRuntime"/>
		/// </summary>
		private static StringDictionary _StatusCodes = new StringDictionary();

		static HttpRuntime() {	
			_StatusCodes.Add("200", "OK");

			_StatusCodes.Add("400", "Bad Request");
			_StatusCodes.Add("404", "Not Found");

			_StatusCodes.Add("500", "Internal Server Error");
			_StatusCodes.Add("501", "Not Implemented");
		}

		/// <summary>
		/// O construtor � privado uma vez que se trata de uma classe utilit�ria da qual n�o
		/// v�o ser criadas inst�ncias.
		/// </summary>
		private HttpRuntime() {	}


		/// <summary>
		/// Recebe o socket com a liga��o estabelecida com o cliente. Usa uma thread do ThreadPool
		/// para processar todos os pedidos do cliente atrav�s desta liga��o 
		/// <see cref="internalProcessRequest"/>
		/// </summary>
		/// <param name="sclient">Socket com a liga��o estabelecida com o cliente</param>
		public static void ProcessRequest(Socket sclient) 
		{
			ThreadPool.QueueUserWorkItem(new WaitCallback(internalProcessRequest), sclient);
		}

		/// <summary>
		/// M�todo que vai ser executado no contexto de uma nova Thread. Este m�todo s� termina o
		/// seu processamento quando a liga��o for fechada.
		/// </summary>
		/// <param name="o">O Socket de liga��o ao cliente</param>
		private static void internalProcessRequest(object o) 
		{
			Socket sclient = (Socket)o;
			do
			{
				HttpContext context = new HttpContext(sclient);
				try 
				{
					try 
					{
						context.ParseRequest();
					} 
					catch(Exception e) 
					{
						throw new HttpException(400, e);
					}

					ContentHandler handler = ContentHandler.GetContentHandler(context);
					if(handler == null) 
					{
						throw new HttpException(404);
					}
					handler.ProcessRequest(context);
					context.Writer.Flush();
					context.OutputStream.Flush();

				}
				catch(HttpException hte) 
				{
					SendErrorResponse(hte.HttpErrorCode, context);
				}
				catch(Exception e) 
				{
					SendErrorResponse(500, context);
				} 
				string closeConn = (string)context.ResponseHeaders["Connection"];

				if(closeConn != null && closeConn.Equals("Close")) 
				{
					context.OutputStream.Close();
						context.Socket.Close();
				}
				Trace.WriteLine("----------------------------------------------------------------\n\n");
				context = null;
				if(sclient.Connected)
					sclient.Poll(-1, SelectMode.SelectRead);
			}	while(sclient.Connected);
		}
		

		/// <summary>
		/// Retorna ao cliente uma resposta HTTP de erro com o erro errorCode
		/// </summary>
		/// <param name="errorCode">C�digo do erro HTTP a retornar </param>
		/// <param name="context">
		/// O objecto HTTPContext com todo o contexto do presente pedido
		/// </param>
		public static void SendErrorResponse(int errorCode, HttpContext context) 
		{
			if(context.Socket.Connected == false)	
				return;
			SendResponse(errorCode, context);
			//context.ResponseHeaders["Connection"] = "Close";
			context.ResponseHeaders["Content-Length"] = "0";
			SendHeaderFields(context);
			context.Writer.Close();
			//context.Socket.Close();
		}
        

		/// <summary>
		/// Retorna ao cliente uma resposta HTTP de sucesso com o c�digo de status statusCode
		/// </summary>
		/// <param name="statusCode">C�digo de staus a retornar ao cliente</param>
		/// <param name="context">
		/// Objecto HTTPContext com todo o contexto do presente pedido
		/// </param>
		public static void SendSuccessfullResponse(int statusCode, HttpContext context) 
		{
			SendResponse(statusCode, context);
		}

		private static void SendResponse(int statusCode, HttpContext context) 
		{
			StringBuilder rsp = new StringBuilder();
			rsp.Append(String.Format("HTTP/1.1 {0} {1}", statusCode, _StatusCodes[statusCode.ToString()]));
			context.Writer.WriteLine(rsp.ToString());

			//context.ResponseHeaders["Server"] = "TI HTTP Server by Luis Falcao";
			context.ResponseHeaders["Server"] = "TI/HTTP Server";
			if(context.ResponseHeaders["Connection"] != null) 
				context.ResponseHeaders["Connection"] = "Keep-Alive";
			//context.ResponseHeaders["Date"] = DateTime.Now.ToUniversalTime().ToString();

			Log.WriteLine(TraceLevel.Verbose, "Response sended:");
			Log.WriteLine(TraceLevel.Verbose, rsp.ToString());
		}


		/// <summary>
		/// Envia todos os header fields (name: value\r\n) da resposta HTTP presentes em context.ResponseHeaders
		/// </summary>
		/// <param name="context">/// Objecto HTTPContext com todo o contexto do presente pedido</param>
		public static void SendHeaderFields(HttpContext context) 
		{

			Log.WriteLine(TraceLevel.Verbose, "Sending Headers: ");
			foreach(DictionaryEntry entry in context.ResponseHeaders) {
				StringBuilder hname = new StringBuilder(entry.Key.ToString());
				hname[0] = char.ToUpper(hname[0]);
				string headerField = String.Format("{0}: {1}", hname.ToString(), entry.Value);
				context.Writer.WriteLine(headerField);
				Log.WriteLine(TraceLevel.Verbose, headerField); 
			}
			context.Writer.WriteLine();
			//context.Writer.Flush();
		}

	}
}
