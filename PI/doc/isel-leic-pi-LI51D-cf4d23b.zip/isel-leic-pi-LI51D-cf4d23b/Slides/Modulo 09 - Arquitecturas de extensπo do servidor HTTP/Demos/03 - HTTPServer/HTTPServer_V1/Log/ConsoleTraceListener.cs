using System;
using System.Diagnostics;



namespace Logging
{
	/// <summary>
	/// Summary description for ConsoleTraceListener.
	/// </summary>
	public class ConsoleTraceListener : TextWriterTraceListener
	{
		public ConsoleTraceListener() : base(System.Console.Out, "Console")
		{
		}
	}
}
