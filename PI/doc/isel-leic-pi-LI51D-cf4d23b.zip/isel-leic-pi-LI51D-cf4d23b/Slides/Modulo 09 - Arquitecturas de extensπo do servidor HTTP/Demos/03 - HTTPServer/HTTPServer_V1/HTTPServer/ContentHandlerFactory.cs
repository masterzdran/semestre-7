using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using System.Web.Configuration;

namespace HTTPServer.ContentHandlers
{
    class ContentHandlerFactory
    {
        /// <summary>
		/// Dicion�rio com os as extens�es url e os respectivos handlers que processam o pedido.
		/// Este dicion�rio � iniciado no construtor de tipo com os valores presentes no ficheiro web.config
        /// em configura��o <see cref="static ContentHandler"/>
		/// </summary>
        private static Dictionary<string, Type> _HandlersMappings = new Dictionary<string, Type>();  

        static ContentHandlerFactory()	
        { 	     
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            HttpHandlersSection hsection = config.GetSection("system.web/httpHandlers") as HttpHandlersSection;

            if (hsection == null)
                return;

            foreach(HttpHandlerAction handler in hsection.Handlers)
            {              
                try
                {
                    string key = handler.Path + ":" + handler.Verb;                  
                    if (!_HandlersMappings.ContainsKey(key))
                    {                    
                        // make sure the type is a subclass of ContenHandler
                        Type type = Type.GetType(handler.Type);
                        if (type.IsSubclassOf(typeof(ContentHandler)) && type.GetConstructor(Type.EmptyTypes) != null)
                            _HandlersMappings.Add(key, type);
                    }
                }catch(Exception)
                {
                      // Ignore an invalid handle an move on to the next one.
                }
            }
		}

        public static ContentHandler GetContentHandler(string urlExtension, string command)
        {
            string key = urlExtension + ":" + command;

            if (!_HandlersMappings.ContainsKey(key))
            {
                key = urlExtension + ":*";
                if (!_HandlersMappings.ContainsKey(key))
                    throw new HttpException(404);
            }

            return (ContentHandler) _HandlersMappings[key].GetConstructor(Type.EmptyTypes).Invoke(null);                         
        }
    }
}
