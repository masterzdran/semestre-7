using System;
using System.Diagnostics;
using System.Resources;
using System.Reflection;
using System.IO;
using System.Text.RegularExpressions;
using System.Collections;


namespace Logging
{
	/// <summary>//
	/// Summary description for ConsoleTraceListener.
	/// </summary>
	public class HTMLTraceListener: LogTraceListener
	{
		private StreamWriter _logStream;
		
		private string		_baseLogDir = Environment.CurrentDirectory + "\\";
		private string		_lastLogDir;
		private long		_maxFileSize = -1; // In KBytes
		private long		_charsWrote = 0;
		private bool		_createDailyLogFolder = false;
		private string		_htmlTemplateString;
		private string		_logFileTitle = null;
		private string		_logFileName = "Log.html";
		private int			_currentFileNameIndex = 0;
		private bool		_deleteExistantFiles = false;


		private const string TITLE_MARK = "<!--##title##-->";
		

		public HTMLTraceListener(string pars) 
		{
		
			try 
			{
				// Extract the parameters
				/*string delimiters = "=,";
				string []parsArray = pars.Split(delimiters.ToCharArray());

				Type thisType = this.GetType();
				for(int i = 0; i < parsArray.Length; i += 2) 
				{
					PropertyInfo prop = thisType.GetProperty(parsArray[i].Trim());
					if(prop == null)
						continue;
					object val = parsArray[i+1];
					Type dstType = prop.PropertyType.UnderlyingSystemType;
					val = Convert.ChangeType(val, dstType);
					prop.SetValue(this, val , null);
				}*/
				this.setProperties(pars);
				
				Assembly currAsm = Assembly.GetExecutingAssembly();
				string asmName = currAsm.GetName().Name; 
                Stream resStream = currAsm.GetManifestResourceStream(asmName + ".LogTemplate.html");
				TextReader htmlTemplate	= new StreamReader(resStream);
				_htmlTemplateString = htmlTemplate.ReadToEnd();


				_htmlTemplateString = _htmlTemplateString.Replace(TITLE_MARK, _logFileTitle);
				createNewLogFile();
				
			} 
			catch(Exception e) 
			{
				GC.SuppressFinalize(this);
				Trace.Listeners.Remove(this);
				Log.WriteLine(TraceLevel.Warning, "[HTMLTraceListener.HTMLTraceListener]: Removed myself from Trace Listeners because the following exception ocurred: {0}{1}", Environment.NewLine, e);
			}
		}
	
		~HTMLTraceListener() 
		{
			Dispose(false);
		}


		private class FileNameComparer : IComparer 
		{
			public int Compare(object x, object y) 
			{
				string s1 = (string)x;
				string s2 = (string)y;
				if(s1.Length == s2.Length)
					return s1.CompareTo(s2);
				return s1.Length > s2.Length ? 1 : -1;
			}
		}

		private void setCurrentFileIndex() 
		{
			_currentFileNameIndex = 0;
			if(Directory.Exists(LogDir) == false) 
			{
				return;
			}
			string fileNamePrefix = _logFileName.Split('.')[0];
			string []files = Directory.GetFiles(LogDir, fileNamePrefix + "*.html");
			if(files.Length == 0)
				return;
			Array.Sort(files,new FileNameComparer());

			if(_deleteExistantFiles) 
			{
				foreach(string fileName in files) 
				{
					File.Delete(fileName);
				}
				return;
			}

			string expr = @"\.(\d+)\.html";
			// Compile the regular expression.
			Regex r = new Regex(expr);
			int idx = files.Length-1;
			Match m = null;
			do 
			{
				m = r.Match(files[idx]);
				if(m == null)
					return;
				if(m.Value != "")
					break;
				if(--idx < 0)
					return;
			} while(true);
			string num = m.Groups[1].Value;
			_currentFileNameIndex = int.Parse(num);

		}

		private void createNewLogFile() 
		{
			if(_logStream != null) 
			{
				writeHTMLTerminationToLogFile();
			}
			
			// Chek if the destination folder exists. If Not, create it
			string logDir = _lastLogDir = this.LogDir;
			if(Directory.Exists(logDir) == false)
				Directory.CreateDirectory(logDir);

			setCurrentFileIndex();
			_currentFileNameIndex++;
			_logStream = new StreamWriter(CurrentLogFileName);
			

			_logStream.AutoFlush = true;
			_logStream.Write(_htmlTemplateString);
			_charsWrote = (long)_htmlTemplateString.Length;
			Writer = _logStream;
			//Stream s = _logStream.BaseStream;
		}

		private void writeHTMLTerminationToLogFile() 
		{
			_logStream.WriteLine("\t\t</div>");
			_logStream.WriteLine("\t</body>");
			_logStream.WriteLine("</html>");
			_logStream.Close();
		}

		public override void Write(string message, string category)
		{
			if(_createDailyLogFolder && _lastLogDir != LogDir)
			{
				createNewLogFile();
			}

			int idx = category.IndexOf(":");
			string categoryCssClass = idx == -1
				? category
				: category.Substring(0, idx);
			message = message.Replace(Environment.NewLine, "<br/>");
			message = String.Format("<div class='{0}'><span class='errorType'>{1}:</span>{2}</div>{3}", categoryCssClass, category, message, Environment.NewLine);
			_charsWrote += (long)message.Length;
			base.Write(message);

			if(category == "None") 
			{
				//base.Write(String.Format("<div class='{0}'>{1}</div>{2}", category, message, Environment.NewLine));
			} 
			else  
			{
				//base.Write(String.Format("<div class='{0}'><span class='errorType'>{1}:</span> {2}</div>{3}", category, category, message, Environment.NewLine));
			}
			if(_maxFileSize != -1 && _charsWrote > _maxFileSize)
			{
				createNewLogFile();
			}
		}

		public override void Write(string message)
		{
			Write(message, "None"); 
		}
	
		public override void WriteLine(string message, string category)
		{
			Write(message + Environment.NewLine, category);			
		}

		public override void WriteLine(string message)
		{
			WriteLine(message, "None"); 
		}
	
		protected override void Dispose(bool disposing)
		{
			if(_logStream != null) 
			{
				if(disposing == false || _logStream.BaseStream == null || _logStream.BaseStream.CanWrite == false) 
				{
					_logStream = new StreamWriter(CurrentLogFileName,true);
				}
				writeHTMLTerminationToLogFile();
			}
			base.Dispose (disposing);
		}

		private string LogDir
		{
			get 
			{ 
				if(_createDailyLogFolder) 
				{
					return String.Format("{0}\\{1}\\", _baseLogDir, DateTime.Now.ToShortDateString());
				} 
				else 
				{
					return _baseLogDir + "\\";
				}
			}
		}

		private string CurrentLogFileName 
		{
			get 
			{ 
				return _lastLogDir+_logFileName.Replace(".html", String.Format(".{0}.html", _currentFileNameIndex));
			}
		}

		public string LogFileName 
		{
			get { return _logFileName; }
			set { 
				_logFileName = value; 
				if(_logStream != null)
					createNewLogFile();
				
			}
		}

		public string LogFileTitle
		{
			get { return _logFileTitle; }
			set { 
				_logFileTitle = value; 
				if(_logStream != null)
					createNewLogFile();
			}
		}

		
		public string BaseLogDir
		{
			get { 
				return _baseLogDir;
			}
			set { 
				_baseLogDir = value; 
				if(_logStream != null)
					createNewLogFile();
			}
		}

		public bool CreateDailyLogFolder
		{
			get { return _createDailyLogFolder; }
			set { 
				_createDailyLogFolder = value; 
				if(_logStream != null)
					createNewLogFile();
			}
		}

		public long MaxFileSize 
		{
			get { return _maxFileSize/1024; }
			set { _maxFileSize = value*1024; }
		}

		public bool DeleteExistantFiles 
		{
			get { return _deleteExistantFiles; }
			set { _deleteExistantFiles = value; }
		}

		
	}
}
