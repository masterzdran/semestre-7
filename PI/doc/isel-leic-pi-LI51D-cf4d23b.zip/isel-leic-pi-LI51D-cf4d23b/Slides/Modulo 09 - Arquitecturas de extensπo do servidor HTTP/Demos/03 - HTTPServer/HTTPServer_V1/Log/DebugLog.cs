using System;
using System.Collections;
using System.Diagnostics;
using System.Xml;
using System.Configuration;

namespace Logging
{
	/// <summary>
	/// Defines methods for other components to write their debug information
	/// Allows listeners to register themselves and sends them the debug information received
	/// </summary>
	public sealed class Log
	{
		
		#region ------------------------- Public Properties ------------------------------
		/// <summary>
		/// Register / unregister console trace listener
		/// </summary>
		public static bool LogToConsole
		{
			get
			{
				return m_bLoggingToConsole;
			}
			set
			{
				if(m_bLoggingToConsole == value)
					return;
				
				m_bLoggingToConsole = !m_bLoggingToConsole;
				if(m_bLoggingToConsole == false) 
				{
					TraceListener ctl = RegisteredInLog(typeof(ConsoleTraceListener));
					Trace.Listeners.Remove(ctl);
					return;
				}
				Trace.Listeners.Add(new ConsoleTraceListener());
			}
		}

		/// <summary>
		/// The global TraceLevel of the application
		/// </summary>
		public static TraceLevel Level 
		{
			get { return m_logSwitch.Level; }
			set 
			{ 
				DateTime now = DateTime.Now;
				string time = now.ToString("yyyy-MM-dd - HH:mm:ss:fff");

				m_logSwitch.Level = value; 
				OnLogLevelChanged();
				string s = String.Format("############ Log Level Set to {0, -8} #####################{1}", m_logSwitch.Level, Environment.NewLine);
				string message = String.Format("[{0}]: {1}", time, s);
				WriteTrace(message);
			}
		}

		public static ComponentsTraceLevel ComponentLevel 
		{
			get { return m_componentsTraceLevel ; }
		}
		#endregion ------------------------- Public Properties ------------------------------

		#region ------------------------- Generic Write methods --------------------------
		/// <summary>
		/// Write a debug information followed by a new line
		/// </summary>
		/// <param name="level">The trace level of the information</param>
		/// <param name="s">The debug information</param>
		public static void WriteLine(TraceLevel level, string s) 
		{
			Write(level, null, s + Environment.NewLine);
		}
		
		/// <summary>
		/// Write a debug information followed by a new line
		/// </summary>
		/// <param name="level">The trace level of the information</param>
		/// <param name="component">Who generated the information</param>
		/// <param name="s">The debug information</param>
		public static void WriteLine(TraceLevel level, string component, string s) 
		{
			Write(level, component, s + Environment.NewLine);
		}

		/// <summary>
		/// Write a debug information followed by a new line
		/// </summary>
		/// <param name="level">The trace level of the information</param>
		/// <param name="component">Who generated the information</param>
		/// <param name="s">The debug information</param>
		/// <param name="args">The arguments of the previous parameter</param>
		public static void WriteLine(TraceLevel level, string component, string s, params object[]args) 
		{
			Write(level, component, s + Environment.NewLine, args);
		}


		/// <summary>
		/// Write a debug information
		/// </summary>
		/// <param name="level">The trace level of the information</param>
		/// <param name="s">The debug information</param>
		public static void Write(TraceLevel level, string s) 
		{
			Write(level, null, s); 		
		}

		/// <summary>
		/// Write a debug information
		/// </summary>
		/// <param name="level">The trace level of the information</param>
		/// <param name="component">Who generated the information</param>
		/// <param name="s">The debug information</param>
		public static void Write(TraceLevel level, string component, string s) 
		{
			TraceLevel componentLevel;
			if(component == null) 
			{
				componentLevel = m_logSwitch.Level;
			} 
			else 
			{
				componentLevel = m_componentsTraceLevel.IsComponentTraceLevelDefined(component) 
					? m_componentsTraceLevel[component] 
					: m_logSwitch.Level; 
			}
			

			if (level <= componentLevel) 
			{
				DateTime now = DateTime.Now;

				string time = now.ToString("yyyy-MM-dd - HH:mm:ss:fff");
				string message = String.Format("[{0}]: {1}", time, s);
				WriteTrace(message, level, component); 
			}
		}

		/// <summary>
		/// Write a debug information
		/// </summary>
		/// <param name="level">The trace level of the information</param>
		/// <param name="component">Who generated the information</param>
		/// <param name="s">The debug information</param>
		/// <param name="args">The arguments of the previous parameter</param>
		public static void Write(TraceLevel level, string component, string s, params object[]args) 
		{
			Write(level, component, String.Format(s,args)); 		
		}

		#endregion ------------------------- Generic Write methods --------------------------
		
		/// Write methods without TraceLevel, with component parameter

		#region Write Error methods

		public static void WriteLineError(string s)
		{
			WriteLine(TraceLevel.Error,null,s);
		}

		public static void WriteLineError(string s, params object[]args)
		{
			WriteLine(TraceLevel.Error,null,s, args);
		}

		public static void WriteLineError(string component,string s)
		{
			WriteLine(TraceLevel.Error,component,s);
		}


		public static void WriteLineError(string component,string s, params object[]args)
		{
			WriteLine(TraceLevel.Error,component,s,args);
		}


		public static void WriteError(string s)
		{
			WriteLine(TraceLevel.Error,null,s);
		}

		public static void WriteError(string s, params object[]args)
		{
			WriteLine(TraceLevel.Error,null,s, args);
		}

		public static void WriteError(string component,string s)
		{
			Write(TraceLevel.Error,component,s);
		}
		public static void WriteError(string component,string s, params object[]args)
		{
			Write(TraceLevel.Error,component,s,args);
		}
		#endregion // Write Error methods

		#region Write Warning methods

		public static void WriteLineWarning(string s)
		{
			WriteLine(TraceLevel.Warning,null,s);
		}

		public static void WriteLineWarning(string s, params object[]args)
		{
			WriteLine(TraceLevel.Warning,null,s, args);
		}

		public static void WriteLineWarning(string component,string s)
		{
			WriteLine(TraceLevel.Warning,component,s);
		}
		public static void WriteLineWarning(string component,string s, params object[]args)
		{
			WriteLine(TraceLevel.Warning,component,s,args);
		}


		public static void WriteWarning(string s)
		{
			WriteLine(TraceLevel.Warning,null,s);
		}

		public static void WriteWarning(string s, params object[]args)
		{
			WriteLine(TraceLevel.Warning,null,s, args);
		}
		public static void WriteWarning(string component,string s)
		{
			Write(TraceLevel.Warning,component,s);
		}
		public static void WriteWarning(string component,string s, params object[]args)
		{
			Write(TraceLevel.Warning,component,s,args);
		}

		#endregion //Write Warning methods

		#region Write Info methods

		public static void WriteLineInfo(string s)
		{
			WriteLine(TraceLevel.Info,null,s);
		}
		public static void WriteLineInfo(string s, params object[]args)
		{
			WriteLine(TraceLevel.Info,null,s, args);
		}
		public static void WriteLineInfo(string component,string s)
		{
			WriteLine(TraceLevel.Info,component,s);
		}
		public static void WriteLineInfo(string component,string s, params object[]args)
		{
			WriteLine(TraceLevel.Info,component,s,args);
		}

		public static void WriteInfo(string s)
		{
			WriteLine(TraceLevel.Info,null,s);
		}
		public static void WriteInfo(string s, params object[]args)
		{
			WriteLine(TraceLevel.Info,null,s, args);
		}
		public static void WriteInfo(string component,string s)
		{
			Write(TraceLevel.Info,component,s);
		}
		public static void WriteInfo(string component,string s, params object[]args)
		{
			Write(TraceLevel.Info,component,s,args);
		}

		#endregion // Write Info methods

		#region Write Info methods

		public static void WriteLineVerbose(string s)
		{
			WriteLine(TraceLevel.Verbose,null,s);
		}
		public static void WriteLineVerbose(string s, params object[]args)
		{
			WriteLine(TraceLevel.Verbose,null,s, args);
		}
		public static void WriteLineVerbose(string component,string s)
		{
			WriteLine(TraceLevel.Verbose,component,s);
		}
		public static void WriteLineVerbose(string component,string s, params object[]args)
		{
			WriteLine(TraceLevel.Verbose,component,s,args);
		}

		public static void WriteVerbose(string s)
		{
			WriteLine(TraceLevel.Verbose,null,s);
		}
		public static void WriteVerbose(string s, params object[]args)
		{
			WriteLine(TraceLevel.Verbose,null,s, args);
		}

		public static void WriteVerbose(string component,string s)
		{
			Write(TraceLevel.Verbose,component,s);
		}
		public static void WriteVerbose(string component,string s, params object[]args)
		{
			Write(TraceLevel.Verbose,component,s,args);
		}
		#endregion //Write Info methods

		#region ------------------------- Public events --------------------------------
		/// <summary>
		/// Event Fires when a Log message is written
		/// </summary>
		public static LogMessageEventHandler LogMessage;

		/// <summary>
		/// Event Fires when the Log level changes
		/// </summary>
		public static LogLevelChangedEventHandler LogLevelChanged;

		#endregion ------------------------- Public events ------------------------------

		#region ------------------------- Private methods ------------------------------

		/// <summary>
		/// Type constructor
		/// </summary>
		static Log()
		{ 
			m_bLoggingToConsole = RegisteredInLog(typeof(ConsoleTraceListener)) != null;
            // Get the configuration file.
            System.Configuration.Configuration config =
                ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);

            // Get the AppSetins section.
            ConfigurationSection diagsSettingSection = 
                (ConfigurationSection)config.GetSection("system.diagnostics");
            // Since the returned instance type (SystemDiagnosticsSection) is 
            // internal(I don't know why) to the System assembly, I have to use 
            // reflection to access the Switches property
            ConfigurationElementCollection switches = (ConfigurationElementCollection)diagsSettingSection.GetType().GetProperty("Switches").GetGetMethod().Invoke(diagsSettingSection, null);

			//Hashtable switches = (Hashtable)((Hashtable)ConfigurationSettings.GetConfig("system.diagnostics"))["switches"];
			
			foreach(Object sw in switches) 
			{
                // Each Element is a switchElement, wich is internal also.
                // Refelction again. The must be a way to do this properly, but
                // I have no time to find out right now
                Type t = sw.GetType();
            
                string key = (string)t.GetProperty("Name").GetGetMethod().Invoke(sw, null);
                string mainSwitchName = m_logSwitch.DisplayName;
                if(key.StartsWith(mainSwitchName) && key != mainSwitchName) 
                {
                    String value = (string)t.GetProperty("Value").GetGetMethod().Invoke(sw, null);
                    TraceLevel level = (TraceLevel)Enum.Parse(typeof(TraceLevel), value, true);
                    ComponentLevel[key.Substring(mainSwitchName.Length, key.Length-mainSwitchName.Length)] = level;
                }
			}
		}

		/// <summary>
		/// Find a trace listener given its type
		/// </summary>
		/// <param name="t">The type of the trace listener to find</param>
		/// <returns>The trace listener of the desired type or null if none is found</returns>
		private static TraceListener RegisteredInLog(Type t) 
		{
			foreach(TraceListener tl in Trace.Listeners) 
			{
				if(tl.GetType() == t) 
				{
					return tl;
				}
			}
			return null;
		}

		private static void OnLogMessage(LogMessageEventArgs args) 
		{
			if(LogMessage != null) 
				LogMessage(args);
		}

		private static void OnLogLevelChanged() 
		{
			if(LogLevelChanged != null) 
				LogLevelChanged(new LogLevelChangedEventArgs(m_logSwitch.Level));
		}

		private static void WriteTrace(string message) 
		{
			Trace.Write(message);
			OnLogMessage(new LogMessageEventArgs(message));
		}

		private static void WriteTrace(string message, TraceLevel level) 
		{
			Trace.Write(message, level.ToString());
			OnLogMessage(new LogMessageEventArgs(message, level));
		}

		private static void WriteTrace(string message, TraceLevel level, string component)
		{
			string componentAndCategory = String.Format("{0}:{1}", level, component == null ? "" : component);
			Trace.Write(message, componentAndCategory);
			OnLogMessage(new LogMessageEventArgs(message, level, component));
		}
			
		#endregion ------------------------- Private methods ------------------------------

		#region ------------------------- Private fields --------------------------------

		/// <summary>
		/// Allows the same debug information to be logged by multiple listeners
		/// </summary>
		private static TraceSwitch m_logSwitch = new TraceSwitch("Log", "The Log Trace Switch");

		/// <summary>
		/// Is there a console listener?
		/// </summary>
		private static bool m_bLoggingToConsole;

		/// <summary>
		/// Configuration document with the trace levels for the different components
		/// </summary>
		//private static XmlNode m_xmlLogConfiguration;

		/// <summary>
		/// Trace level container for each components 
		/// </summary>
		private static ComponentsTraceLevel m_componentsTraceLevel = new ComponentsTraceLevel();

		#endregion ------------------------- Private fields ------------------------------
	}


	
	/// <summary>
	/// Delegates associated to the public events
	/// </summary>
	public delegate void LogMessageEventHandler(LogMessageEventArgs args);

	public delegate void LogLevelChangedEventHandler(LogLevelChangedEventArgs args);


	public class ComponentsTraceLevel
	{
		System.Collections.Hashtable _componentsTraceLevel = new Hashtable();

		public TraceLevel this[string componentName] 
		{
			get 
			{
				object level = _componentsTraceLevel[componentName];
				return level == null ? TraceLevel.Verbose : (TraceLevel)level;
			}

			set 
			{
				_componentsTraceLevel[componentName] = value;
			}
		}

		public bool IsComponentTraceLevelDefined(string componentName) 
		{
			return _componentsTraceLevel[componentName] != null;
		}
	}

	/// <summary>
	/// EventArgs derived type to pass as argument to LogMessage event.
	/// </summary>
	[Serializable]
	public class LogMessageEventArgs: EventArgs 
	{
		private string _message;

		public TraceLevel _messageLevel;

		private String _component;

		
		/// <summary>
		/// Creates a new instance of LogMessageEventArgs class with the
		/// specified message. 
		/// </summary>
		/// <param name="message">Information to be logged</param>
		public LogMessageEventArgs(string message)
			: this(message, TraceLevel.Off, null) {
		}


		/// <summary>
		/// Creates a new instance of LogMessageEventArgs class with the
		/// given message and TraceLevel. 
		/// </summary>
		/// <param name="message">The log message produced</param>
		/// <param name="level">The logged message <see cref="TraceLevel">TraceLevel</see> </param>
		public LogMessageEventArgs(string message, TraceLevel level) 
			: this(message, level, null)
		{
}

		/// <summary>
		/// Creates a new instance of LogMessageEventArgs class with the
		/// given message and TraceLevel and for the given component. 
		/// </summary>
		/// <param name="message">The log message produced</param>
		/// <param name="level">The logged message <see cref="TraceLevel">TraceLevel</see> </param>
		/// <param name="component">The component taht generated the Log message</param>
		public LogMessageEventArgs(string message, TraceLevel level, string component) 
		{
			_message = message;
			_messageLevel = level;
			_component = component;
		}


		/// <summary>
		/// The Logged message.
		/// </summary>
		public string Message 
		{
			get {
				return _message;
			}
		}

		/// <summary>
		/// The trace level of the logged Message. 
		/// If TraceLevel not defined this property returns TraceLevel.Off.
		/// </summary>
		public TraceLevel MessageTraceLevel
		{
			get 
			{
				return _messageLevel;
			}
		}

		/// <summary>
		/// The component taht generated the Log message. If this log
		/// message was not generated by any component this property 
		/// returns null
		/// </summary>
		public String Component
		{
			get {
				return _component;
			}
		}
	}

	
	
	/// <summary>
	/// EventArgs derived type to pass as argument to LogLevelChanged 
	/// event.
	/// This type has the new LogLevel 
	/// </summary>
	[Serializable]
	public class LogLevelChangedEventArgs: EventArgs 
	{

		/// <summary>
		/// Current log level of the application
		/// </summary>
		public readonly TraceLevel LogLevel;
		/// <summary>
		/// Class containing the arguments of the LogLevelChanged event
		/// </summary>
		/// <param name="level">New log level</param>
		/// 
		public LogLevelChangedEventArgs(TraceLevel level) 
		{
			LogLevel = level;
		}
	}
}
