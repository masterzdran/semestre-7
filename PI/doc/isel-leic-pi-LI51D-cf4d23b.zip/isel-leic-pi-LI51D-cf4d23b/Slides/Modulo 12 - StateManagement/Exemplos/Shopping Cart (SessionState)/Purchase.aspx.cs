﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;


public partial class Purchase : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        ArrayList cart = (ArrayList)Session["Cart"];
        m_ItemsInCart.Text = cart.Count.ToString();
    }

    private void AddItem(string desc, int cost)
    {
        ArrayList cart = (ArrayList)Session["Cart"];
        cart.Add(new SessionState.Item(desc, cost));
        m_ItemsInCart.Text = cart.Count.ToString();
    }

    protected void LinkButton1_Click(object sender, System.EventArgs e)
    {
        // add pencil (€1) to shopping cart
        AddItem("pencil", 1);
    }

    protected void LinkButton2_Click(object sender, System.EventArgs e)
    {
        // add pen (€2) to shopping cart
        AddItem("pen", 2);
    }

    protected void LinkButton3_Click(object sender, System.EventArgs e)
    {
        // add ruler (€3) to shopping cart
        AddItem("ruler", 3);
    }

    protected void LinkButton4_Click(object sender, System.EventArgs e)
    {
        // add calculator (€10) to shopping cart
        AddItem("calculator", 10);
    }
}
