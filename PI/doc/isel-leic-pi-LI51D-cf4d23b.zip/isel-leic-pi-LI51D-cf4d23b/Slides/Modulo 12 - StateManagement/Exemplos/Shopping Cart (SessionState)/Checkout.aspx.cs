﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

public partial class Checkout : System.Web.UI.Page
{
    protected void buy_click(object sender, EventArgs e) 
    {
        //Limpar a sessão
        Session["Cart"] = new ArrayList();
        Buy.Visible = false;
        DataGrid1.Visible = false;
        BuyLabel.Text = "Obrigado, volte sempre.!";
       
    }
    
    protected void Page_PreRender(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            int totalCost = 0;            

            ArrayList cart = (ArrayList)Session["Cart"];
            
            foreach (SessionState.Item item in cart)
            {
                totalCost += item.Cost;                
            }

            BuyLabel.Text = String.Format("Total cost: ${0}", totalCost);
            
            DataGrid1.DataSource = cart;
            DataGrid1.DataBind();
        }
      }
}
