﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;


public partial class Purchase : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        ArrayList cart = (ArrayList)ViewState["Cart"];
        if (cart == null)
        {
            cart = new ArrayList();
            ViewState["Cart"] = cart;
        }
        else
            m_ItemsInCart.Text = cart.Count.ToString();
    }

    private void PopulatePurchaseTable()
    {
        ArrayList cart = (ArrayList)ViewState["Cart"];
        if (cart == null)
            return;
        
        int totalCost = 0;

        TableRow tr;
        TableCell tc;
        foreach (ViewState.Item item in cart)
        {
            totalCost += item.Cost;
            tr = new TableRow();
            tc = new TableCell();
            tc.Text = string.Format("Item: {0}, Cost: €{1}<br>", item.Description, item.Cost);
            tr.Cells.Add(tc);
            m_PurchaseTable.Rows.Add(tr);
        }

        tr = new TableRow();
        tc = new TableCell();
        tc.Text = string.Format("<p>Total cost: €{0}</p>", totalCost);
        tr.Cells.Add(tc);
        m_PurchaseTable.Rows.Add(tr);

      
      
    }
    private void AddItem(string desc, int cost)
    {
        ArrayList cart = (ArrayList)ViewState["Cart"];
        cart.Add(new ViewState.Item(desc, cost));
        m_ItemsInCart.Text = cart.Count.ToString();
        PopulatePurchaseTable();
    }

    protected void LinkButton1_Click(object sender, System.EventArgs e)
    {
        // add pencil (€1) to shopping cart
        AddItem("pencil", 1);
    }

    protected void LinkButton2_Click(object sender, System.EventArgs e)
    {
        // add pen (€2) to shopping cart
        AddItem("pen", 2);
    }

    protected void LinkButton3_Click(object sender, System.EventArgs e)
    {
        // add ruler (€3) to shopping cart
        AddItem("ruler", 3);
    }

    protected void LinkButton4_Click(object sender, System.EventArgs e)
    {
        // add calculator (€10) to shopping cart
        AddItem("calculator", 10);
    }

    protected void Buy_Click(object sender, System.EventArgs e)
    {
        ViewState["Cart"] = new ArrayList();
        //transferir a execução para a página e checkout. 
        //Neste caso apenas apresenta uma mensagem de conclusão.
        Server.Transfer("checkout.aspx");        
    }

}
