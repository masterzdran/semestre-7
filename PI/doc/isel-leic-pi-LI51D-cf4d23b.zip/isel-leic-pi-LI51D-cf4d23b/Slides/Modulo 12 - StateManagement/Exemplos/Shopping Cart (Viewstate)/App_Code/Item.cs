using System;

namespace ViewState
{
  [Serializable]
  public class Item
  {
    private string m_description;
    private int    m_cost;

    public Item(string description, int cost)
    {
      m_description = description;
      m_cost = cost;
    }

    public Item()
    {
      m_description = "";
      m_cost = 0;
    }

    public string Description
    {
      get { return m_description; }
      set { m_description = value; }
    }
    public int Cost
    {
      get { return m_cost; }
      set { m_cost = value; }
    }
  }
}
