﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

public partial class Purchase : System.Web.UI.Page
{
    private ArrayList m_Cart;
    protected void Page_Load(object sender, EventArgs e)
    {
        m_Cart = CookieState.Item.HydrateArrayListFromCookies();
        m_ItemsInCart.Text = m_Cart.Count.ToString();     
    }

    private void AddItem(string desc, int cost)
    {
        m_Cart.Add(new CookieState.Item(desc, cost));
        m_ItemsInCart.Text = m_Cart.Count.ToString();
    }

    protected void Page_PreRender(object src, EventArgs e)
    {
        CookieState.Item.SaveArrayListToCookies(m_Cart);
    }

    protected void LinkButton1_Click(object sender, System.EventArgs e)
    {
        // add pencil ($1) to shopping cart
        AddItem("pencil", 1);
    }

    protected void LinkButton2_Click(object sender, System.EventArgs e)
    {
        // add pen ($2) to shopping cart
        AddItem("pen", 2);
    }

    protected void LinkButton3_Click(object sender, System.EventArgs e)
    {
        // add ruler ($3) to shopping cart
        AddItem("ruler", 3);
    }

    protected void LinkButton4_Click(object sender, System.EventArgs e)
    {
        // add calculator ($10) to shopping cart
        AddItem("calculator", 10);
    }
}
