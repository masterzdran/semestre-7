﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

public partial class Checkout : System.Web.UI.Page
{
    private ArrayList m_Cart;
    protected void Page_Load(object sender, EventArgs e)
    {
        int totalCost = 0;

        m_Cart = CookieState.Item.HydrateArrayListFromCookies();
        foreach (CookieState.Item item in m_Cart)
        {
            totalCost += item.Cost;            
        }

        DataGrid1.DataSource = m_Cart;
        DataGrid1.DataBind();
        BuyLabel.Text =String.Format("Total cost: ${0}", totalCost);
    }
    protected void buy_click(object sender, EventArgs e)
    {
        m_Cart.Clear();
        Buy.Visible = false;
        BuyLabel.Text="Obrigado, volte sempre.!";
        DataGrid1.Visible = false;
        CookieState.Item.SaveArrayListToCookies(new ArrayList());
    }
}
