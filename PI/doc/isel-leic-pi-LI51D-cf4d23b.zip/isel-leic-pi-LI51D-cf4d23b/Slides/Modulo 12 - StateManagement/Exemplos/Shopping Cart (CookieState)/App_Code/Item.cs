using System;
using System.Collections;
using System.Web;


namespace CookieState
{
    [Serializable]
    public class Item
{
  private string m_description;
  private int    m_cost;

  public Item(string description, int cost)
  {
    m_description = description;
    m_cost = cost;
  }

  public string Description
  {
    get { return m_description; }
    set { m_description = value; }
  }
  public int Cost
  {
    get { return m_cost; }
    set { m_cost = value; }
  }

   public static ArrayList HydrateArrayListFromCookies()
  {
    int itemCount = 0;
    HttpCookie itemCountCookie = HttpContext.Current.Request.Cookies["ItemCount"];
    if (itemCountCookie != null)
      itemCount = Convert.ToInt32(itemCountCookie.Value);
    else
    {
      itemCountCookie = new HttpCookie("ItemCount");
      itemCountCookie.Value = "0";
      HttpContext.Current.Response.Cookies.Add(itemCountCookie);
    }

    ArrayList cart = new ArrayList();
    for (int i = 0; i < itemCount; i++)
    {
      int cost = Convert.ToInt32(HttpContext.Current.Request.Cookies[i.ToString() + "cost"].Value);
      string desc = HttpContext.Current.Request.Cookies[i.ToString() + "desc"].Value;
      cart.Add(new Item(desc, cost));
    }

    return cart;
  }
  public static void SaveArrayListToCookies(ArrayList cart)
  {
    // Save array size first
    HttpCookie itemCountCookie = new HttpCookie("ItemCount");
    itemCountCookie.Value = cart.Count.ToString();
    HttpContext.Current.Response.Cookies.Add(itemCountCookie);

    int i = 0;
    foreach (Item item in cart)
    {
      HttpCookie descCookie = new HttpCookie(i.ToString() + "desc");
      descCookie.Value = item.Description;
      HttpContext.Current.Response.Cookies.Add(descCookie);

      HttpCookie costCookie = new HttpCookie(i.ToString() + "cost");
      costCookie.Value = item.Cost.ToString();
      HttpContext.Current.Response.Cookies.Add(costCookie);
      i++;
    }

  }
}

}