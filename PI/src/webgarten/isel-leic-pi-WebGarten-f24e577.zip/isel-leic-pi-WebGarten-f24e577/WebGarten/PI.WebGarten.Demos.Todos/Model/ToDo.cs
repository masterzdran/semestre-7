namespace PI.WebGarten.Demos.Todos.Model
{
    class ToDo
    {
        public int Id { get; set; }
        public string Description { get; set; }    
    }
}